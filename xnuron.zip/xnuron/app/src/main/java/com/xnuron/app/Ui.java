package com.xnuron.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/** Material 3 style tokens (dynamic colour on Android 12+, static baseline otherwise) and small view factories. */
final class Ui {
    final float d;
    final boolean night;
    int primary, onPrimary, primaryContainer, onPrimaryContainer, surface, onSurface, onSurfaceVariant,
        container, containerHigh, error, errorContainer, onErrorContainer, outline;

    Ui(Context c) {
        d = c.getResources().getDisplayMetrics().density;
        night = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (Build.VERSION.SDK_INT >= 31) dynamic(c); else baseline();
        error = night ? 0xFFF2B8B5 : 0xFFB3261E;
        errorContainer = night ? 0xFF8C1D18 : 0xFFF9DEDC;
        onErrorContainer = night ? 0xFFF9DEDC : 0xFF410E0B;
    }

    private void baseline() {
        if (night) {
            primary = 0xFFD0BCFF; onPrimary = 0xFF381E72; primaryContainer = 0xFF4F378B; onPrimaryContainer = 0xFFEADDFF;
            surface = 0xFF141218; onSurface = 0xFFE6E0E9; onSurfaceVariant = 0xFFCAC4D0;
            container = 0xFF211F26; containerHigh = 0xFF2B2930; outline = 0xFF938F99;
        } else {
            primary = 0xFF6750A4; onPrimary = 0xFFFFFFFF; primaryContainer = 0xFFEADDFF; onPrimaryContainer = 0xFF21005D;
            surface = 0xFFFEF7FF; onSurface = 0xFF1D1B20; onSurfaceVariant = 0xFF49454F;
            container = 0xFFF3EDF7; containerHigh = 0xFFECE6F0; outline = 0xFF79747E;
        }
    }

    @android.annotation.TargetApi(31)
    private void dynamic(Context c) {
        if (night) {
            primary = c.getColor(android.R.color.system_accent1_200); onPrimary = c.getColor(android.R.color.system_accent1_800);
            primaryContainer = c.getColor(android.R.color.system_accent1_700); onPrimaryContainer = c.getColor(android.R.color.system_accent1_100);
            surface = c.getColor(android.R.color.system_neutral1_900); onSurface = c.getColor(android.R.color.system_neutral1_100);
            onSurfaceVariant = c.getColor(android.R.color.system_neutral2_200);
            container = c.getColor(android.R.color.system_neutral1_800); containerHigh = c.getColor(android.R.color.system_neutral1_700);
            outline = c.getColor(android.R.color.system_neutral2_400);
        } else {
            primary = c.getColor(android.R.color.system_accent1_600); onPrimary = c.getColor(android.R.color.system_accent1_0);
            primaryContainer = c.getColor(android.R.color.system_accent1_100); onPrimaryContainer = c.getColor(android.R.color.system_accent1_900);
            surface = c.getColor(android.R.color.system_neutral1_10); onSurface = c.getColor(android.R.color.system_neutral1_900);
            onSurfaceVariant = c.getColor(android.R.color.system_neutral2_700);
            container = c.getColor(android.R.color.system_neutral1_50); containerHigh = c.getColor(android.R.color.system_neutral1_100);
            outline = c.getColor(android.R.color.system_neutral2_500);
        }
    }

    int dp(float v) { return Math.round(v * d); }

    GradientDrawable shape(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusDp * d);
        return g;
    }

    void systemBars(Activity a) {
        a.getWindow().setStatusBarColor(surface);
        a.getWindow().setNavigationBarColor(surface);
        int f = a.getWindow().getDecorView().getSystemUiVisibility();
        if (!night) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        a.getWindow().getDecorView().setSystemUiVisibility(f);
    }

    TextView text(Context c, float sp, int color, boolean medium) {
        TextView t = new TextView(c);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        return t;
    }

    /** Pill button, no shadow, ripple in the content colour. */
    Button pill(Context c, String label, int bg, int fg, float heightDp, float sp) {
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(sp);
        b.setTextColor(fg);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0); b.setMinimumHeight(dp(heightDp));
        b.setMinWidth(0); b.setMinimumWidth(0);
        b.setPadding(dp(20), 0, dp(20), 0);
        if (Build.VERSION.SDK_INT >= 21) b.setStateListAnimator(null);
        style(b, bg, fg);
        return b;
    }

    void style(Button b, int bg, int fg) {
        GradientDrawable g = shape(bg, 60);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf((fg & 0x00FFFFFF) | 0x33000000), g, null));
        b.setTextColor(fg);
    }

    static int withAlpha(int c, int a) { return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)); }
}
