#include "machine.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <pthread.h>

#define LOG_CAP (1u << 20)

typedef struct { uint64_t addr; uint32_t enable, frame; } Fb;
typedef struct { uint32_t x, y, state, seq, ctrl, status; } Touch;

struct A64Machine {
    A64MachineKind kind;
    A64 cpu;
    uint8_t *ram; uint64_t ram_base, ram_size;
    volatile int stop;
    A64MState state;
    pthread_mutex_t lock;
    char *slog[3]; size_t slen[3];
    Fb fb; Touch touch;
    uint64_t entry;
    bool reported_end;
    bool raw, attempt;
    unsigned impl_n; unsigned impl_key[96]; uint64_t impl_val[96]; unsigned char impl_seen[96]; uint64_t pmin, pmax, calm_exc; unsigned calm;   /* stuck-loop detector (attempt machines only) */
    uint64_t virt_base, phys_base;
    struct S5l { void *m; uint32_t r[0x40]; } s5l[3]; unsigned s5l_n;
};

/* ----------------------------------------------------------------- log */
/* Three streams: ALL (chronological, what tests read), GUEST (only what the guest itself wrote: UART / HLE output)
 * and EMU (only what the emulator says about itself). */
static void stream_add(A64Machine *m, int s, const char *p, size_t n) {
    const size_t cap = LOG_CAP - 32;
    if (m->slen[s] >= cap) return;
    if (n > cap - m->slen[s]) n = cap - m->slen[s];
    memcpy(m->slog[s] + m->slen[s], p, n); m->slen[s] += n;
    if (m->slen[s] >= cap) { const char *t = "\n[log truncated]\n"; memcpy(m->slog[s] + m->slen[s], t, strlen(t)); m->slen[s] += strlen(t); }
}
static void log_raw_k(A64Machine *m, const char *s, size_t n, int kind) {   /* kind: 1 guest, 2 emulator */
    pthread_mutex_lock(&m->lock);
    stream_add(m, 0, s, n); stream_add(m, kind, s, n);
    pthread_mutex_unlock(&m->lock);
}
static void log_raw(A64Machine *m, const char *s, size_t n) { log_raw_k(m, s, n, 1); }   /* guest output */
void a64m_log(A64Machine *m, const char *fmt, ...) {
    char b[2048]; va_list ap; va_start(ap, fmt); int n = vsnprintf(b, sizeof b, fmt, ap); va_end(ap);
    if (n < 0) return; if ((size_t)n >= sizeof b) n = sizeof b - 1;
    log_raw_k(m, b, (size_t)n, 2);
}
size_t a64m_log_read_kind(A64Machine *m, int kind, size_t off, char *buf, size_t cap) {
    if (kind < 0 || kind > 2) return 0;
    pthread_mutex_lock(&m->lock);
    size_t n = off < m->slen[kind] ? m->slen[kind] - off : 0; if (n > cap) n = cap;
    if (n) memcpy(buf, m->slog[kind] + off, n);
    pthread_mutex_unlock(&m->lock);
    return n;
}
size_t a64m_log_read(A64Machine *m, size_t off, char *buf, size_t cap) { return a64m_log_read_kind(m, 0, off, buf, cap); }
size_t a64m_log_size(A64Machine *m) { pthread_mutex_lock(&m->lock); size_t n = m->slen[0]; pthread_mutex_unlock(&m->lock); return n; }

/* ------------------------------------------------------------- devices */
static void update_irq(A64Machine *m) {
    bool line = (m->touch.ctrl & 1) && (m->touch.status & 1);
    __atomic_store_n(&m->cpu.irq_line, line, __ATOMIC_RELEASE);
}
static uint64_t uart_r(void *u, uint64_t off, unsigned sz) { (void)u; (void)sz; return off == 0x18 ? 0x90 : 0; }
static void uart_w(void *u, uint64_t off, unsigned sz, uint64_t v) {
    (void)sz; if (off == 0) { char ch = (char)v; log_raw((A64Machine *)u, &ch, 1); }
}

/* Apple S5L (Samsung-style) UART, as the XNU serial driver uses it (offsets as I know them, unverified): ULCON 0x00, UCON 0x04, UFCON 0x08, UMCON 0x0c,
 * UTRSTAT 0x10 (bit0 rx data, bit1 tx buffer empty, bit2 tx shifter empty), UFSTAT 0x18, UTXH 0x20, URXH 0x24. MODELLED: the transmitter is always empty,
 * nothing is ever received, every other register reads back what was last written. Bytes written to UTXH go to the guest log (the kernel's own console). */
static uint64_t s5l_r(void *u, uint64_t off, unsigned sz) {
    struct S5l *d = u; (void)sz;
    switch (off) { case 0x10: return 0x6; case 0x18: return 0; case 0x1c: return 0; case 0x24: return 0; default: return off < sizeof d->r ? d->r[off >> 2] : 0; }
}
static void s5l_w(void *u, uint64_t off, unsigned sz, uint64_t v) {
    struct S5l *d = u; (void)sz;
    if (off == 0x20) { char ch = (char)v; log_raw((A64Machine *)d->m, &ch, 1); return; }
    if (off < sizeof d->r) d->r[off >> 2] = (uint32_t)v;
}
int a64m_add_s5l_uart(A64Machine *m, uint64_t pa, uint64_t size) {
    if (m->s5l_n >= 3) return -1;
    struct S5l *d = &m->s5l[m->s5l_n]; d->m = m;
    static const char *names[3] = { "s5l-uart-a", "s5l-uart-b", "s5l-uart-c" };
    A64Dev dev = { pa, size ? size : 0x4000, s5l_r, s5l_w, d, names[m->s5l_n] };
    if (a64_add_device(&m->cpu, &dev)) return -1;
    m->s5l_n++; return 0;
}
static uint64_t fb_r(void *u, uint64_t off, unsigned sz) {
    A64Machine *m = u; (void)sz;
    switch (off) {
    case 0x00: return A64M_FB_W; case 0x04: return A64M_FB_H;
    case 0x08: return m->fb.addr & 0xFFFFFFFFu; case 0x0C: return m->fb.addr >> 32;
    case 0x10: return m->fb.enable; case 0x14: return m->fb.frame; case 0x1C: return 1;
    default: return 0;
    }
}
static void fb_w(void *u, uint64_t off, unsigned sz, uint64_t v) {
    A64Machine *m = u; (void)sz;
    switch (off) {
    case 0x08: m->fb.addr = (m->fb.addr & ~0xFFFFFFFFull) | (v & 0xFFFFFFFFu); break;
    case 0x0C: m->fb.addr = (m->fb.addr & 0xFFFFFFFFull) | (v << 32); break;
    case 0x10: m->fb.enable = (uint32_t)(v & 1); break;
    case 0x18: __atomic_add_fetch(&m->fb.frame, 1, __ATOMIC_RELEASE); break;
    default: break;
    }
}
static uint64_t touch_r(void *u, uint64_t off, unsigned sz) {
    A64Machine *m = u; (void)sz;
    switch (off) {
    case 0x00: return m->touch.x; case 0x04: return m->touch.y; case 0x08: return m->touch.state;
    case 0x0C: return m->touch.seq; case 0x10: return m->touch.ctrl; case 0x14: return m->touch.status;
    default: return 0;
    }
}
static void touch_w(void *u, uint64_t off, unsigned sz, uint64_t v) {
    A64Machine *m = u; (void)sz;
    if (off == 0x10) { m->touch.ctrl = (uint32_t)(v & 1); update_irq(m); }
    else if (off == 0x14) { if (v & 1) __atomic_and_fetch(&m->touch.status, ~1u, __ATOMIC_ACQ_REL); update_irq(m); }
}
static void sys_w(void *u, uint64_t off, unsigned sz, uint64_t v) {
    A64Machine *m = u; (void)sz;
    if (off == 0) { m->cpu.halted = true; m->cpu.exit_code = (int)(uint32_t)v; }
}
static uint64_t sys_r(void *u, uint64_t off, unsigned sz) { (void)u; (void)off; (void)sz; return 0; }

void a64m_touch(A64Machine *m, int x, int y, bool down) {
    if (x < 0) x = 0; if (y < 0) y = 0;
    m->touch.x = (uint32_t)x; m->touch.y = (uint32_t)y; m->touch.state = down;
    __atomic_add_fetch(&m->touch.seq, 1, __ATOMIC_RELEASE);
    __atomic_or_fetch(&m->touch.status, 1u, __ATOMIC_ACQ_REL);
    update_irq(m);
}

int64_t a64m_frame(A64Machine *m, uint32_t *dst, int w, int h) {
    if (!m->fb.enable) return -1;
    uint64_t bytes = (uint64_t)A64M_FB_W * A64M_FB_H * 4;
    uint8_t *p = a64m_ram_at(m, m->fb.addr, bytes);
    if (!p || w != A64M_FB_W || h != A64M_FB_H) return -1;
    const uint32_t *s = (const uint32_t *)(const void *)p;
    for (int k = 0; k < A64M_FB_W * A64M_FB_H; k++) dst[k] = 0xFF000000u | (s[k] & 0xFFFFFFu);
    return (int64_t)__atomic_load_n(&m->fb.frame, __ATOMIC_ACQUIRE);
}

/* ---------------------------------------------------------- lifecycle */
static void user_out(void *u, const char *b, size_t n) { log_raw((A64Machine *)u, b, n); }
static void unimpl_svc(void *u, bool bsd, uint64_t num) {
    a64m_log((A64Machine *)u, "[emu] unimplemented %s syscall %llu (returned ENOSYS)\n", bsd ? "BSD/XNU" : "Linux", (unsigned long long)num);
}

static A64Machine *alloc_m(A64MachineKind k, uint64_t base, uint64_t size) {
    size = (size + 0xFFFF) & ~0xFFFFull;
    A64Machine *m = calloc(1, sizeof *m); if (!m) return NULL;
    m->kind = k; m->ram_base = base; m->ram_size = size;
    m->ram = calloc(1, size);
    for (int s = 0; s < 3; s++) m->slog[s] = calloc(1, LOG_CAP);
    if (!m->ram || !m->slog[0] || !m->slog[1] || !m->slog[2]) { free(m->ram); for (int s = 0; s < 3; s++) free(m->slog[s]); free(m); return NULL; }
    pthread_mutex_init(&m->lock, NULL);
    a64_init(&m->cpu, m->ram, base, size);
    m->state = A64M_CREATED;
    return m;
}

A64Machine *a64m_create_system(uint64_t ram_size) {
    A64Machine *m = alloc_m(A64M_KIND_SYSTEM, A64M_RAM_BASE, ram_size);
    if (!m) return NULL;
    a64_system_init(&m->cpu);
    A64Dev d[4] = {
        { A64M_UART_BASE, 0x1000, uart_r, uart_w, m, "uart" },
        { A64M_FB_BASE, 0x1000, fb_r, fb_w, m, "fb" },
        { A64M_TOUCH_BASE, 0x1000, touch_r, touch_w, m, "touch" },
        { A64M_SYSCON, 0x1000, sys_r, sys_w, m, "syscon" },
    };
    for (int k = 0; k < 4; k++) a64_add_device(&m->cpu, &d[k]);
    m->cpu.pc = m->entry = A64M_RAM_BASE;
    return m;
}
A64Machine *a64m_create_user(uint64_t base, uint64_t size) {
    A64Machine *m = alloc_m(A64M_KIND_USER, base, size);
    if (!m) return NULL;
    m->cpu.out = user_out; m->cpu.ud = m; m->cpu.on_unimpl_svc = unimpl_svc;
    return m;
}
void a64m_destroy(A64Machine *m) {
    if (!m) return;
    pthread_mutex_destroy(&m->lock); free(m->cpu.cov); free(m->cpu.callseen); free(m->ram); for (int s = 0; s < 3; s++) free(m->slog[s]); free(m);
}
A64 *a64m_cpu(A64Machine *m) { return &m->cpu; }
void a64m_mark_raw(A64Machine *m) { m->raw = true; }
static uint64_t impl_reg(void *u, unsigned k, bool wr, uint64_t v);
void a64m_mark_attempt(A64Machine *m, uint64_t vb, uint64_t pb) { m->cpu.stub_impl_regs = true; m->cpu.on_impl_reg = impl_reg; m->cpu.impl_ud = m; m->attempt = true; m->virt_base = vb; m->phys_base = pb; }
void a64m_set_pc(A64Machine *m, uint64_t pc) { m->cpu.pc = m->entry = pc; }
void a64m_abort(A64Machine *m, const char *why) {
    a64m_log(m, "\n[boot] ATTEMPT ENDED BEFORE ANY GUEST INSTRUCTION RAN: %s\n", why);
    m->state = A64M_FAULT; m->reported_end = true;
}
void a64m_set_mpidr(A64Machine *m, uint64_t v) { m->cpu.mpidr = v; }
void a64m_set_store_watch(A64Machine *m, uint64_t pa, uint64_t len) { m->cpu.sw_lo = pa; m->cpu.sw_hi = pa + len; }
static uint64_t g_dt_phys, g_diag_va[4], g_diag_len[4], g_ddv[3], g_ddl[3]; static unsigned g_diag_n;
void a64m_set_diag_code(A64Machine *m, uint64_t va, uint64_t len) { (void)m; if (!va) { g_diag_n = 0; return; } if (g_diag_n < 4) { g_diag_va[g_diag_n] = va; g_diag_len[g_diag_n] = len; g_diag_n++; } }
void a64m_set_diag_data(A64Machine *m, uint64_t va, uint64_t len) { a64m_set_diag_data2(m, 0, va, len); }
void a64m_set_diag_data2(A64Machine *m, unsigned idx, uint64_t va, uint64_t len) { (void)m; if (idx < 3) { g_ddv[idx] = va; g_ddl[idx] = len; } }
void a64m_set_store_watch2(A64Machine *m, int i, uint64_t pa, uint64_t len) { m->cpu.swb[i].lo = pa; m->cpu.swb[i].hi = pa + len; }
static uint64_t g_ref_va[4]; static unsigned g_ref_n;
void a64m_set_coverage(A64Machine *m, uint64_t base, uint64_t len) {
    free(m->cpu.cov); free(m->cpu.callseen); m->cpu.cov = calloc((size_t)(len / 32 + 1), 1); m->cpu.callseen = calloc((size_t)(len / 32 + 1), 1);
    m->cpu.cov_base = base; m->cpu.cov_len = len; m->cpu.call_total = 0;
    if (!m->cpu.cov || !m->cpu.callseen) { free(m->cpu.cov); free(m->cpu.callseen); m->cpu.cov = m->cpu.callseen = NULL; m->cpu.cov_len = 0; }
}
void a64m_set_ref_scan(A64Machine *m, unsigned idx, uint64_t va) { (void)m; if (idx < 4) { g_ref_va[idx] = va; if (idx + 1 > g_ref_n) g_ref_n = idx + 1; } }
/* find instructions that reference a kernel global: ADRP rd, page ; then within 6 words LDR/STR (unsigned offset) or ADD with Rn==rd and the exact page offset */
static void dump_refs(A64Machine *m) {
    if (!m->cpu.cov) return;
    { unsigned tot = m->cpu.call_total, n = tot < 160 ? tot : 160;
      a64m_log(m, "[panic] the last %u of %u functions called for the FIRST time (bl targets), oldest first, 8 per line:\n", n, tot);
      for (unsigned q = 0; q < n; q += 8) { char l2[200]; int o2 = 0; for (unsigned r = q; r < q + 8 && r < n; r++) o2 += snprintf(l2 + o2, sizeof l2 - (size_t)o2, " %llx", (unsigned long long)m->cpu.callring[(tot - n + r) % 160]); a64m_log(m, "[panic] %s\n", l2); } }
    if (!g_ref_n) return;
    uint64_t lo = m->cpu.cov_base, len = m->cpu.cov_len;
    for (unsigned t = 0; t < g_ref_n; t++) {
        uint64_t tv = g_ref_va[t]; if (!tv) continue;
        a64m_log(m, "[panic] instructions that reference kernel global 0x%llx (ADRP+LDR/STR/ADD; '+' ran, '-' never ran; l = load, s = STORE, a = address taken):\n", (unsigned long long)tv);
        char ln[240]; int o = 0; unsigned found = 0, quiet = 0;
        uint8_t *base = a64m_ram_at(m, m->phys_base + (lo - m->virt_base), (size_t)len);
        if (!base) { a64m_log(m, "[panic]  (image not addressable)\n"); continue; }
        for (uint64_t off = 0; off + 4 <= len && found < 400; off += 4) {
            uint32_t w; memcpy(&w, base + off, 4);
            if ((w & 0x9f000000u) != 0x90000000u) continue;
            int64_t imm = (int64_t)(((w >> 5) & 0x7ffffu) << 2 | ((w >> 29) & 3u)); if (imm & 0x100000) imm -= 0x200000;
            uint64_t page = ((lo + off) & ~0xfffull) + (uint64_t)(imm << 12);
            if (page != (tv & ~0xfffull)) continue;
            unsigned rd = w & 31;
            for (int k = 1; k <= 6 && off + 4 + 4 * (uint64_t)k <= len + 4; k++) {
                if (off + 4 * (uint64_t)k + 4 > len) break;
                uint32_t v; memcpy(&v, base + off + 4 * (uint64_t)k, 4);
                if (((v >> 5) & 31) != rd) continue;
                uint64_t offv = (uint64_t)-1;
                if ((v & 0x3b000000u) == 0x39000000u) offv = (uint64_t)((v >> 10) & 0xfff) << (v >> 30);
                else if ((v & 0xff800000u) == 0x91000000u) offv = (v >> 10) & 0xfff;
                if (offv != (tv & 0xfff)) continue;
                uint64_t pcv = lo + off + 4 * (uint64_t)k; uint64_t co = pcv - lo;
                int ran = (m->cpu.cov[co >> 5] >> ((co >> 2) & 7)) & 1;
                char kind = ((v & 0xff800000u) == 0x91000000u) ? 'a' : (((v >> 22) & 3) == 0 ? 's' : 'l');   /* a = address (ADD), s = store, l = load */
                found++;
                if (!ran && kind == 'l') { quiet++; break; }   /* never-executed plain loads are only counted */
                o += snprintf(ln + o, sizeof ln - (size_t)o, " %c%c%llx", ran ? '+' : '-', kind, (unsigned long long)pcv);
                if (o > 200) { a64m_log(m, "[panic] %s\n", ln); o = 0; }
                break;
            }
        }
        if (o) a64m_log(m, "[panic] %s\n", ln);
        a64m_log(m, "[panic]  %u references in all, %u of them never-executed plain loads (not listed)\n", found, quiet);
        if (!found) a64m_log(m, "[panic]  (none found)\n");
    }
}
void a64m_set_pc_trace(A64Machine *m, uint64_t va) { m->cpu.tr_pc = va; m->cpu.tr_n = 0; m->cpu.tr_on = 0; }
void a64m_set_call_trace(A64Machine *m, uint64_t va) { m->cpu.ctr_pc = va; m->cpu.ctr_mode = 0; }
void a64m_set_call_trace_regs(A64Machine *m, uint64_t va) { m->cpu.ctr_pc = va; m->cpu.ctr_mode = 1; }
void a64m_set_dt_phys(A64Machine *m, uint64_t pa) { (void)m; g_dt_phys = pa; }
void a64m_set_boot_arg(A64Machine *m, uint64_t v) { m->cpu.x[0] = v; m->cpu.watch_lo = v; m->cpu.watch_hi = v + 0x400; }
uint8_t *a64m_ram_at(A64Machine *m, uint64_t a, uint64_t len) {
    if (a < m->ram_base) return NULL;
    uint64_t o = a - m->ram_base;
    if (o > m->ram_size || len > m->ram_size - o) return NULL;
    return m->ram + o;
}
int a64m_load_raw(A64Machine *m, const uint8_t *data, size_t len, uint64_t addr) {
    if (!addr) addr = m->ram_base;
    uint8_t *p = a64m_ram_at(m, addr, len);
    if (!p) return -1;
    memcpy(p, data, len);
    m->cpu.pc = m->entry = addr;
    return 0;
}

/* Apple implementation-defined registers (IPSW attempts only).  Model: a register reads back the last value written
 * (0 if never written); a few registers have documented-by-observation "ready" bits forced on so that the kernel's
 * wait loops can proceed.  This is an ASSUMPTION made to see how far the kernel gets, not real hardware behaviour.
 * Each distinct (register, direction) is logged once. */
#define IMPL_MAX 96
static const struct { unsigned key; uint64_t force_bits; const char *why; } IMPL_READY[] = {
    { (3u << 14) | (4u << 11) | (15u << 7) | (0u << 3) | 4u, 0x2, "kernel polls bit 1 right before enabling the MMU; assumed 'ready'" },
};
static uint64_t impl_reg(void *u, unsigned k, bool wr, uint64_t v) {
    A64Machine *m = u; int idx = -1;
    for (unsigned i = 0; i < m->impl_n; i++) if (m->impl_key[i] == k) { idx = (int)i; break; }
    if (idx < 0 && m->impl_n < IMPL_MAX) { idx = (int)m->impl_n++; m->impl_key[idx] = k; m->impl_val[idx] = 0; m->impl_seen[idx] = 0; }
    unsigned bit = wr ? 2u : 1u;
    if (idx >= 0 && !(m->impl_seen[idx] & bit)) {
        m->impl_seen[idx] |= bit;
        a64m_log(m, "[emu] Apple register S3_%u_C%u_C%u_%u %s%s (modelled: reads back last written value, NOT real behaviour)\n", (k >> 11) & 7, (k >> 7) & 15, (k >> 3) & 15, k & 7,
                 wr ? "first write, value 0x" : "first read", "");
        if (wr) a64m_log(m, "[emu]   0x%llx\n", (unsigned long long)v);
    }
    if (wr) { if (idx >= 0) m->impl_val[idx] = v; return 0; }
    uint64_t r = idx >= 0 ? m->impl_val[idx] : 0;
    for (unsigned i = 0; i < sizeof IMPL_READY / sizeof *IMPL_READY; i++)
        if (IMPL_READY[i].key == k) {
            if (!(m->impl_seen[idx] & 4u)) { m->impl_seen[idx] |= 4u; a64m_log(m, "[emu]   assumption: bits 0x%llx read as 1 (%s)\n", (unsigned long long)IMPL_READY[i].force_bits, IMPL_READY[i].why); }
            r |= IMPL_READY[i].force_bits;
        }
    return r;
}

/* --------------------------------------------------------------- running */
void a64m_request_stop(A64Machine *m) { m->stop = 1; }
A64MState a64m_state(const A64Machine *m) { return m->state; }
int a64m_exit_code(const A64Machine *m) { return m->cpu.exit_code; }

#define STUCK_CHUNKS 2500        /* 2500 x 20000 = 50M instructions without leaving a 64 KiB window */
#define STUCK_WINDOW 0x10000
static void dump_code(A64Machine *m, uint64_t lo, uint64_t hi);
static void dump_code_cap(A64Machine *m, uint64_t lo, uint64_t hi, uint64_t cap);
static bool read_word(A64Machine *m, uint64_t a, uint32_t *x);
static const char *ec_name(uint32_t ec) {
    switch (ec) {
    case 0x00: return "unknown/undefined instruction"; case 0x01: return "WFI/WFE trap"; case 0x15: return "SVC"; case 0x18: return "MSR/MRS/SYS trap";
    case 0x20: return "instruction abort (lower EL)"; case 0x21: return "instruction abort (same EL)"; case 0x22: return "PC alignment";
    case 0x24: return "data abort (lower EL)"; case 0x25: return "data abort (same EL)"; case 0x26: return "SP alignment"; case 0x3c: return "BRK"; default: return "other";
    }
}
static void dump_exceptions(A64Machine *m) {
    const A64 *c = &m->cpu;
    if (c->mode != A64_MODE_SYSTEM || !c->exc_first_n) return;
    a64m_log(m, "[panic] first %d exceptions the guest took (instruction count, kind, cause, ELR, FAR):\n", c->exc_first_n);
    for (int k = 0; k < c->exc_first_n; k++) {
        uint32_t esr = c->exc_first[k].esr;
        if (c->exc_first[k].kind == 0)
            a64m_log(m, "[panic]  #%d at instr %llu: sync ESR=0x%08x (%s, ISS 0x%x) ELR=0x%llx FAR=0x%llx\n", k, (unsigned long long)c->exc_first[k].steps, esr, ec_name(esr >> 26), esr & 0x1FFFFFF,
                     (unsigned long long)c->exc_first[k].elr, (unsigned long long)c->exc_first[k].far);
        else a64m_log(m, "[panic]  #%d at instr %llu: interrupt ELR=0x%llx\n", k, (unsigned long long)c->exc_first[k].steps, (unsigned long long)c->exc_first[k].elr);
    }
    if (c->exc0_valid) {
        a64m_log(m, "[panic] registers at the FIRST exception (ELR=0x%llx):\n", (unsigned long long)c->exc_first[0].elr);
        for (int i = 0; i < 31; i += 4) {
            char b[200]; int n = 0;
            for (int k = i; k < i + 4 && k < 31; k++) n += snprintf(b + n, sizeof b - (size_t)n, "x%-2d=%016llx ", k, (unsigned long long)c->exc0_x[k]);
            a64m_log(m, "[panic]  %s\n", b);
        }
        a64m_log(m, "[panic]  sp=%016llx\n", (unsigned long long)c->exc0_sp);
        dump_code(m, c->exc_first[0].elr, c->exc_first[0].elr);
        a64m_log(m, "[panic] call chain at the first exception (frame pointer: return address):");
        { char cb[400]; int cn = 0; for (unsigned q = 0; q < c->exc0_chain_n; q++) cn += snprintf(cb + cn, sizeof cb - (size_t)cn, " %llx:%llx", (unsigned long long)c->exc0_chain[q][0], (unsigned long long)c->exc0_chain[q][1]); a64m_log(m, "%s\n", cb); }
        for (int r = 0; r < 8; r++) {
            char sb[80]; int ok = 0, len = 0;
            for (int q = 0; q < 64; q += 4) { uint32_t w; if (!read_word(m, c->exc0_x[r] + (uint64_t)q, &w)) break; for (int z = 0; z < 4; z++) { unsigned ch = (w >> (8 * z)) & 0xFF; if (!ch) { q = 64; break; } if (ch < 32 || ch > 126) { ok = -1; q = 64; break; } sb[len++] = (char)ch; } }
            if (ok == 0 && len >= 4) { sb[len] = 0; a64m_log(m, "[panic]  x%d points to the text \"%s\"\n", r, sb); }
            else if ((c->exc0_x[r] >> 40) == 0xfffffffull && !(c->exc0_x[r] & 7)) {
                uint32_t w[8]; int okw = 1; for (int q = 0; q < 8; q++) if (!read_word(m, c->exc0_x[r] + 4u * (uint64_t)q, &w[q])) { okw = 0; break; }
                if (okw) a64m_log(m, "[panic]  x%d points to the 64-bit words %llx %llx %llx %llx\n", r, (unsigned long long)(w[0] | (uint64_t)w[1] << 32), (unsigned long long)(w[2] | (uint64_t)w[3] << 32), (unsigned long long)(w[4] | (uint64_t)w[5] << 32), (unsigned long long)(w[6] | (uint64_t)w[7] << 32));
            }
        }
        if ((c->exc_first[0].esr >> 26) != 0) {   /* an undefined-instruction first exception is the guest's own panic trap: these lists would only be noise */
        a64m_log(m, "[panic] the last %u data accesses before the first exception (pc: R/W size virtual-address = value):\n", c->exc0_acc_n);
        for (unsigned q = 0; q < c->exc0_acc_n; q += 2) {
            char ab[300]; int an = 0;
            for (unsigned k = q; k < q + 2 && k < c->exc0_acc_n; k++) an += snprintf(ab + an, sizeof ab - (size_t)an, " %llx:%s%u %llx=%llx", (unsigned long long)c->exc0_acc[k].pc, c->exc0_acc[k].wr ? "W" : "R", c->exc0_acc[k].sz, (unsigned long long)c->exc0_acc[k].va, (unsigned long long)c->exc0_acc[k].val);
            a64m_log(m, "[panic] %s\n", ab);
        }
        a64m_log(m, "[panic] the %u instructions executed just before the first exception (pc:word):\n", c->exc0_pcn);
        for (unsigned q = 0; q < c->exc0_pcn; q += 4) {
            char b[300]; int n = 0;
            for (unsigned k = q; k < q + 4 && k < c->exc0_pcn; k++) { uint32_t x = 0; bool ok = read_word(m, c->exc0_pc[k], &x); n += snprintf(b + n, sizeof b - (size_t)n, " %llx:%s", (unsigned long long)c->exc0_pc[k], "") ; if (ok) n += snprintf(b + n, sizeof b - (size_t)n, "%08x", x); else n += snprintf(b + n, sizeof b - (size_t)n, "????????"); }
            a64m_log(m, "[panic] %s\n", b);
        }
        }
        char w[400];
        if (c->exc_first[0].esr >> 26 == 0x25 || c->exc_first[0].esr >> 26 == 0x24) { a64_walk_trace((A64 *)c, c->exc_first[0].far, w, sizeof w); a64m_log(m, "[panic] first fault address: %s\n", w); }
    }
}
/* text strings referenced by ADRP + ADD pairs in a code window (they name the function: panic texts, log messages) */
static void dump_strs(A64Machine *m, uint64_t va, uint64_t len) {
    uint8_t *p = a64m_ram_at(m, m->phys_base + (va - m->virt_base), len); if (!p) return;
    for (uint64_t o = 0; o + 16 <= len; o += 4) {
        uint32_t w; memcpy(&w, p + o, 4);
        if ((w & 0x9f000000u) != 0x90000000u) continue;
        int64_t imm = (int64_t)(((w >> 5) & 0x7ffffu) << 2 | ((w >> 29) & 3u)); if (imm & 0x100000) imm -= 0x200000;
        uint64_t page = ((va + o) & ~0xfffull) + (uint64_t)(imm << 12); unsigned rd = w & 31;
        for (int k = 1; k <= 3; k++) {
            uint32_t v; memcpy(&v, p + o + 4 * (uint64_t)k, 4);
            if ((v & 0xff800000u) != 0x91000000u || ((v >> 5) & 31) != rd) continue;
            uint64_t a = page + ((v >> 10) & 0xfff);
            uint8_t *s = a64m_ram_at(m, m->phys_base + (a - m->virt_base), 64); if (!s) break;
            char t[72]; int n = 0; while (n < 64 && s[n] >= 32 && s[n] < 127) { t[n] = (char)s[n]; n++; } t[n] = 0;
            if (n >= 4 && s[n] == 0) a64m_log(m, "[panic]  string at 0x%llx referenced at 0x%llx: \"%s\"\n", (unsigned long long)a, (unsigned long long)(va + o), t);
            break;
        }
    }
}
static uint64_t g_caller_va;
void a64m_set_caller_scan(A64Machine *m, uint64_t va) { (void)m; g_caller_va = va; }
/* the function containing g_caller_va (nearest PACIBSP, hint #27, going backwards) and everything that calls it with BL */
static void dump_callers(A64Machine *m) {
    if (!g_caller_va || !m->cpu.cov) return;
    uint64_t lo = m->cpu.cov_base, len = m->cpu.cov_len;
    uint8_t *base = a64m_ram_at(m, m->phys_base + (lo - m->virt_base), (size_t)len); if (!base) return;
    uint64_t f = g_caller_va & ~3ull, lim = f > lo + 0x1000 ? f - 0x1000 : lo; uint32_t w = 0;
    for (; f >= lim; f -= 4) { memcpy(&w, base + (f - lo), 4); if (w == 0xd503237fu) break; }
    if (w != 0xd503237fu) { a64m_log(m, "[panic] no function start (PACIBSP) found within 0x1000 bytes before 0x%llx\n", (unsigned long long)g_caller_va); return; }
    a64m_log(m, "[panic] the function containing 0x%llx starts at 0x%llx; BL calls to it (+ ran / - never ran), with the start of the calling function:\n", (unsigned long long)g_caller_va, (unsigned long long)f);
    unsigned n = 0;
    for (uint64_t off = 0; off + 4 <= len && n < 16; off += 4) {
        uint32_t v; memcpy(&v, base + off, 4);
        if ((v & 0xfc000000u) != 0x94000000u) continue;
        int64_t d = (int64_t)(v & 0x3ffffffu); if (d & 0x2000000) d -= 0x4000000;
        if (lo + off + (uint64_t)(d * 4) != f) continue;
        uint64_t cf = lo + off; uint32_t z = 0; uint64_t cl = cf > lo + 0x4000 ? cf - 0x4000 : lo;
        for (; cf >= cl; cf -= 4) { memcpy(&z, base + (cf - lo), 4); if (z == 0xd503237fu) break; }
        uint64_t co = lo + off - lo; int ran = (m->cpu.cov[co >> 5] >> ((co >> 2) & 7)) & 1;
        a64m_log(m, "[panic]  %cbl at 0x%llx, in the function starting at 0x%llx\n", ran ? '+' : '-', (unsigned long long)(lo + off), (unsigned long long)(z == 0xd503237fu ? cf : 0));
        n++;
    }
    if (!n) a64m_log(m, "[panic]  (no direct BL to it found; it may be called through a pointer)\n");
}
static void dump_diag(A64Machine *m) {
    for (unsigned w = 0; w < g_diag_n; w++) { a64m_log(m, "[panic] diagnostic code window %u:\n", w); dump_code_cap(m, g_diag_va[w], g_diag_va[w] + g_diag_len[w], g_diag_len[w] + 0x20); dump_strs(m, g_diag_va[w], g_diag_len[w] + 0x20); }
    for (unsigned k = 0; k < 3; k++) {
        if (!g_ddl[k]) continue;
        uint64_t dv = g_ddv[k], dl = g_ddl[k];
        a64m_log(m, "[panic] diagnostic data window %u at kernel virtual 0x%llx (64-bit words, 4 per line):\n", k, (unsigned long long)dv);
        for (uint64_t o = 0; o < dl; o += 32) {
            uint64_t w[4] = {0}, tpa = 0; uint8_t *p = (a64_virt_to_phys(&m->cpu, dv + o, &tpa) == 0) ? a64m_ram_at(m, tpa, 32) : a64m_ram_at(m, m->phys_base + (dv + o - m->virt_base), 32);   /* 0.4.19: through the guest page tables, so zone/aperture addresses work too */
            if (!p) { a64m_log(m, "[panic]  %llx: (outside RAM)\n", (unsigned long long)(dv + o)); break; }
            memcpy(w, p, 32);
            a64m_log(m, "[panic]  %llx (pa %llx): %llx %llx %llx %llx\n", (unsigned long long)(dv + o), (unsigned long long)tpa, (unsigned long long)w[0], (unsigned long long)w[1], (unsigned long long)w[2], (unsigned long long)w[3]);
        }
    }
}
static void dump_watch(A64Machine *m) {
    const A64 *c = &m->cpu;
    if (c->xab_n) a64m_log(m, "[panic] accesses to physical addresses with no RAM and no device: %u, the first was a %s at 0x%llx\n", c->xab_n, c->xab_w ? "write" : "read", (unsigned long long)c->xab_pa);
    if (c->at_n) a64m_log(m, "[panic] AT (address translation) instructions executed: %llu, last: va=0x%llx PAR_EL1=0x%llx\n", (unsigned long long)c->at_n, (unsigned long long)c->at_va, (unsigned long long)c->at_par);
    a64m_log(m, "[panic] TPIDR_EL1 writes by the guest: %u%s", c->tp_n, c->tp_n ? " (pc=value):" : " (never written)");
    for (unsigned k = 0; k < c->tp_n; k++) a64m_log(m, " %llx=%llx", (unsigned long long)c->tp_log[k][0], (unsigned long long)c->tp_log[k][1]);
    a64m_log(m, "\n");
    if (c->sw_hi) {
        a64m_log(m, "[panic] stores to watched kernel global (phys 0x%llx.., first %u; size value pc):\n", (unsigned long long)c->sw_lo, c->sw_n);
        for (unsigned k = 0; k < c->sw_n; k++) a64m_log(m, "[panic]  +0x%llx %u 0x%llx pc=0x%llx\n", (unsigned long long)(c->sw[k].addr - c->sw_lo), c->sw[k].sz, (unsigned long long)c->sw[k].val, (unsigned long long)c->sw[k].pc);
        if (c->sw_n >= 3) {
            char w[400]; uint64_t v = c->sw[2].val;
            a64_walk_trace((A64 *)c, v, w, sizeof w);
            a64m_log(m, "[panic] the DT pointer the kernel finally stored, 0x%llx: %s\n", (unsigned long long)v, w);
        }
        if (g_dt_phys) {
            uint8_t *p = a64m_ram_at(m, g_dt_phys, 32);
            if (p) { uint32_t q[8]; memcpy(q, p, 32); a64m_log(m, "[panic] first 8 words at the DT's physical address 0x%llx now: %x %x %x %x %x %x %x %x\n", (unsigned long long)g_dt_phys, q[0], q[1], q[2], q[3], q[4], q[5], q[6], q[7]); }
        }
        for (unsigned k = 3; k-- > 0; ) {   /* latest first: the log can be cut, the interesting store is #2 */
            if (k >= c->sw_n || k != 2) continue;
            a64m_log(m, "[panic] store #%u registers (as of the store):\n", k);
            for (int r = 0; r < 31; r += 4) a64m_log(m, "[panic]  x%d=%llx x%d=%llx x%d=%llx x%d=%llx\n", r, (unsigned long long)c->sw_x[k][r], r+1, (unsigned long long)c->sw_x[k][r+1], r+2, (unsigned long long)c->sw_x[k][r+2], r+3, r+3 < 31 ? (unsigned long long)c->sw_x[k][r+3] : 0ull);
        }
    }
    for (int i = 0; i < 2; i++) if (c->swb[i].hi) {
        a64m_log(m, "[panic] stores to kernel global phys 0x%llx (first %u; value pc):", (unsigned long long)c->swb[i].lo, c->swb[i].n);
        for (unsigned k = 0; k < c->swb[i].n; k++) a64m_log(m, " %llx@%llx", (unsigned long long)c->swb[i].e[k].val, (unsigned long long)c->swb[i].e[k].pc);
        uint8_t *p = a64m_ram_at(m, c->swb[i].lo, 8); uint64_t cur = 0; if (p) memcpy(&cur, p, 8);
        a64m_log(m, " | now %llx\n", (unsigned long long)cur);
    }
    if (c->tr_pc) {
        a64m_log(m, "[panic] the %u instructions executed from the first execution of pc 0x%llx on (pc only, 8 per line):\n", c->tr_n, (unsigned long long)c->tr_pc);
        for (unsigned q = 0; q < c->tr_n; q += 8) {
            char ln[200]; int o = 0;
            for (unsigned r = q; r < q + 8 && r < c->tr_n; r++) o += snprintf(ln + o, sizeof ln - o, " %llx", (unsigned long long)c->tr_pcs[r]);
            a64m_log(m, "[panic] %s\n", ln);
        }
    }
    if (c->ctr_pc && c->ctr_mode == 1) {
        unsigned tot = c->ctr_total, n = tot < 40 ? tot : 40;
        a64m_log(m, "[panic] the last %u of %u executions of pc 0x%llx (x0 x8 x9 x10 x24 x25 x26 x27), oldest first:\n", n, tot, (unsigned long long)c->ctr_pc);
        for (unsigned q = 0; q < n; q++) { unsigned k2 = tot < 40 ? q : (tot + q) % 40;
            a64m_log(m, "[panic]  #%u %llx %llx %llx %llx %llx %llx %llx %llx\n", tot - n + q, (unsigned long long)c->ctr[k2][0], (unsigned long long)c->ctr[k2][1], (unsigned long long)c->ctr[k2][2], (unsigned long long)c->ctr[k2][3], (unsigned long long)c->ctr[k2][4], (unsigned long long)c->ctr[k2][5], (unsigned long long)c->ctr[k2][6], (unsigned long long)c->ctr[k2][7]); }
    } else if (c->ctr_pc) {
        a64m_log(m, "[panic] calls to 0x%llx (only delta!=0, first %u; x0 x1 x2 x3 x4 x5 x6 lr):\n", (unsigned long long)c->ctr_pc, c->ctr_n);
        for (unsigned k = 0; k < c->ctr_n; k++) a64m_log(m, "[panic]  #%u %llx %llx %llx %llx %llx %llx %llx lr=%llx\n", k, (unsigned long long)c->ctr[k][0], (unsigned long long)c->ctr[k][1], (unsigned long long)c->ctr[k][2], (unsigned long long)c->ctr[k][3], (unsigned long long)c->ctr[k][4], (unsigned long long)c->ctr[k][5], (unsigned long long)c->ctr[k][6], (unsigned long long)c->ctr[k][7]);
    }
    if (!c->watch_n || !getenv("A64_DUMP_BOOTARGS_WATCH")) return;   /* boot_args accesses are known; omitted to keep the log short */
    a64m_log(m, "[panic] guest accesses to boot_args (first %u; offset size R/W value pc):\n", c->watch_n);
    for (unsigned k = 0; k < c->watch_n; k++)
        a64m_log(m, "[panic]  +0x%llx %u %s 0x%llx pc=0x%llx\n", (unsigned long long)(c->watch[k].addr - c->watch_lo), c->watch[k].sz, c->watch[k].wr ? "W" : "R", (unsigned long long)c->watch[k].val, (unsigned long long)c->watch[k].pc);
    for (unsigned k = 0; k < c->watch_n; k++) if (c->watch[k].addr - c->watch_lo >= 96 && c->watch[k].addr - c->watch_lo < 104 && !c->watch[k].wr) { a64m_log(m, "[panic] code around the first read of deviceTreeP:\n"); dump_code(m, c->watch[k].pc - 0x30, c->watch[k].pc + 0x30); break; }
}
static void dump_regs(A64Machine *m) {
    const A64 *c = &m->cpu;
    for (int i = 0; i < 31; i += 4) {
        char b[160]; int n = 0;
        for (int k = i; k < i + 4 && k < 31; k++) n += snprintf(b + n, sizeof b - (size_t)n, "x%-2d=%016llx ", k, (unsigned long long)c->x[k]);
        a64m_log(m, "[panic] %s\n", b);
    }
    a64m_log(m, "[panic] sp=%016llx pc=%016llx el=%d daif=%x NZCV=%d%d%d%d\n", (unsigned long long)c->sp, (unsigned long long)c->pc, c->el, c->daif, c->n, c->z, c->c, c->v);
    if (c->mode == A64_MODE_SYSTEM) {
        a64m_log(m, "[panic] SCTLR_EL1=%llx TCR_EL1=%llx TTBR0_EL1=%llx TTBR1_EL1=%llx VBAR_EL1=%llx\n", (unsigned long long)c->sctlr_el1, (unsigned long long)c->tcr_el1,
                 (unsigned long long)c->ttbr0_el1, (unsigned long long)c->ttbr1_el1, (unsigned long long)c->vbar_el1);
        a64m_log(m, "[panic] ESR_EL1=%llx ELR_EL1=%llx FAR_EL1=%llx\n", (unsigned long long)c->esr_el1, (unsigned long long)c->elr_el1, (unsigned long long)c->far_el1);
        char w[400];
        a64_walk_trace((A64 *)c, c->far_el1, w, sizeof w); a64m_log(m, "[panic] %s\n", w);
        a64_walk_trace((A64 *)c, c->elr_el1, w, sizeof w); a64m_log(m, "[panic] %s\n", w);
        for (int k = 0; k < 2; k++) {                       /* raw words at the low bits-cleared TTBR, to spot alignment assumptions */
            uint64_t base = (k ? c->ttbr1_el1 : c->ttbr0_el1) & 0x0000FFFFFFFFFFC0ull;
            uint8_t *t = a64m_ram_at(m, base, 64);
            if (!t) { a64m_log(m, "[panic] TTBR%d base 0x%llx is outside RAM\n", k, (unsigned long long)base); continue; }
            char b[260]; int n = snprintf(b, sizeof b, "[panic] first 8 words at TTBR%d&~0x3f (0x%llx):", k, (unsigned long long)base);
            for (int e = 0; e < 8; e++) { uint64_t d; memcpy(&d, t + e * 8, 8); n += snprintf(b + n, sizeof b - (size_t)n, " %llx", (unsigned long long)d); }
            a64m_log(m, "%s\n", b);
        }
    }
}
static bool mmu_on(const A64Machine *m) { return m->cpu.mode == A64_MODE_SYSTEM && (m->cpu.sctlr_el1 & 1); }
/* a = guest address as the CPU sees it (virtual when the MMU is on, physical otherwise) */
static bool read_word(A64Machine *m, uint64_t a, uint32_t *x) {
    uint64_t pa = a;
    if (mmu_on(m) && a64_virt_to_phys(&m->cpu, a, &pa) != 0) return false;
    uint8_t *w = a64m_ram_at(m, pa, 4); if (!w) return false;
    memcpy(x, w, 4); return true;
}
static uint64_t kvirt(const A64Machine *m, uint64_t a) { return mmu_on(m) ? a : a - m->phys_base + m->virt_base; }
static void dump_code_cap(A64Machine *m, uint64_t lo, uint64_t hi, uint64_t cap) {
    lo = (lo & ~3ull) - 16; hi = (hi & ~3ull) + 20;
    if (hi - lo > cap) hi = lo + cap;
    for (uint64_t a = lo; a <= hi;) {
        char b[160]; int n = snprintf(b, sizeof b, "[panic] code 0x%llx (kernel virtual 0x%llx):", (unsigned long long)a, (unsigned long long)kvirt(m, a));
        for (int k = 0; k < 4 && a <= hi; k++, a += 4) { uint32_t x = 0; if (read_word(m, a, &x)) n += snprintf(b + n, sizeof b - (size_t)n, " %08x", x); else n += snprintf(b + n, sizeof b - (size_t)n, " ????????"); }
        a64m_log(m, "%s\n", b);
    }
}
static void dump_code(A64Machine *m, uint64_t lo, uint64_t hi) { dump_code_cap(m, lo, hi, 0x80); }
static bool stuck_check(A64Machine *m) {
    uint64_t pc = m->cpu.pc;
    if (m->calm == 0) { m->pmin = m->pmax = pc; m->calm_exc = m->cpu.exc_count; m->calm = 1; return false; }
    if (pc < m->pmin) m->pmin = pc;
    if (pc > m->pmax) m->pmax = pc;
    if (m->pmax - m->pmin > STUCK_WINDOW) { m->pmin = m->pmax = pc; m->calm = 1; return false; }
    return ++m->calm >= STUCK_CHUNKS;
}

static void finish(A64Machine *m, A64MState st) {
    m->state = st;
    if (m->reported_end) return;
    m->reported_end = true;
    if (st == A64M_FAULT) {
        char hist[A64_PC_HIST * 20 + 8];
        a64_format_pc_history(&m->cpu, hist, sizeof hist);
        a64m_log(m, "\n[emu] EMULATOR FAULT: %s\n[emu] last PCs: %s\n[emu] el=%d steps=%llu exceptions=%llu esr_el1=0x%llx elr_el1=0x%llx far_el1=0x%llx\n",
                 m->cpu.err, hist, m->cpu.el, (unsigned long long)m->cpu.steps, (unsigned long long)m->cpu.exc_count,
                 (unsigned long long)m->cpu.esr_el1, (unsigned long long)m->cpu.elr_el1, (unsigned long long)m->cpu.far_el1);
        if (m->attempt) {
            const A64 *c = &m->cpu; uint64_t pc = c->pc_hist[(c->pc_hist_i + A64_PC_HIST - 1) % A64_PC_HIST];
            uint32_t insn = 0; read_word(m, pc, &insn);
            a64m_log(m, "[panic] last executed pc=0x%llx (kernel virtual 0x%llx), instruction word 0x%08x, x0=0x%llx x1=0x%llx lr=0x%llx sp=0x%llx\n",
                     (unsigned long long)pc, (unsigned long long)kvirt(m, pc), insn,
                     (unsigned long long)c->x[0], (unsigned long long)c->x[1], (unsigned long long)c->x[30], (unsigned long long)c->sp);
            dump_regs(m); dump_diag(m); dump_refs(m); dump_callers(m); dump_exceptions(m); dump_watch(m); dump_code(m, pc, pc);
            a64m_log(m, "[panic] This is the emulator stopping where it lacks a feature (see message above), NOT a guest-kernel panic and NOT iOS booting.\n");
        }
        if (m->raw) a64m_log(m, "[emu] hint: a raw image that faults within a few instructions is usually not AArch64 code at all (32-bit ARM, compressed, encrypted or wrapped in a container). Open the Diagnostics tab and inspect the file.\n");
    } else if (st == A64M_POWEROFF) {
        a64m_log(m, "\n[emu] guest finished, exit code %d, %llu instructions\n", m->cpu.exit_code, (unsigned long long)m->cpu.steps);
    } else if (st == A64M_STOPPED) {
        a64m_log(m, "\n[emu] stopped by user after %llu instructions\n", (unsigned long long)m->cpu.steps);
    }
}

A64MState a64m_run(A64Machine *m, uint64_t max_steps, bool realtime) {
    if (m->state == A64M_POWEROFF || m->state == A64M_FAULT || m->state == A64M_STOPPED) return m->state;
    uint64_t done = 0;
    m->state = A64M_RUNNING;
    while (done < max_steps) {
        if (m->stop) { finish(m, A64M_STOPPED); return m->state; }
        uint64_t chunk = max_steps - done; if (chunk > 20000) chunk = 20000;
        uint64_t before = m->cpu.steps;
        int r = a64_run(&m->cpu, chunk);
        done += m->cpu.steps - before;
        if (r == A64_RUN_FAULT) { finish(m, A64M_FAULT); return m->state; }
        if (m->attempt && r == A64_RUN_LIMIT && stuck_check(m)) {
            pthread_mutex_lock(&m->lock); size_t gout = m->slen[1]; pthread_mutex_unlock(&m->lock);
            if (m->cpu.exc_count)
                snprintf(m->cpu.err, sizeof m->cpu.err, "the guest spins in a tight loop AFTER an exception (pc stayed within 0x%llx..0x%llx for %d million instructions, guest output so far: %zu bytes): "
                         "this is the guest's own exception/panic handler, not a wait for hardware - the cause is the first exception listed below",
                         (unsigned long long)m->pmin, (unsigned long long)m->pmax, STUCK_CHUNKS * 20000 / 1000000, gout);
            else
                snprintf(m->cpu.err, sizeof m->cpu.err, "guest is stuck in a tight loop (pc stayed within 0x%llx..0x%llx for %d million instructions, guest output so far: %zu bytes): "
                         "almost certainly waiting for hardware or a state that a64virt does not provide",
                         (unsigned long long)m->pmin, (unsigned long long)m->pmax, STUCK_CHUNKS * 20000 / 1000000, gout);
            m->cpu.fault = 1;
            a64m_log(m, "\n[panic] loop window virtual 0x%llx..0x%llx\n", (unsigned long long)kvirt(m, m->pmin), (unsigned long long)kvirt(m, m->pmax));
            dump_code(m, m->cpu.pc, m->cpu.pc);
            dump_regs(m); dump_diag(m); dump_refs(m); dump_callers(m); dump_exceptions(m); dump_watch(m);
            if (m->cpu.exc_count)
                a64m_log(m, "[panic] the loop follows an exception: ESR_EL1=0x%llx ELR_EL1=0x%llx (kernel virtual 0x%llx) VBAR_EL1=0x%llx cause: %s\n"
                         "[panic] i.e. the guest hit something this emulator lacks, installed its own handler, and that handler just spins.\n",
                         (unsigned long long)m->cpu.esr_el1, (unsigned long long)m->cpu.elr_el1, (unsigned long long)kvirt(m, m->cpu.elr_el1),
                         (unsigned long long)m->cpu.vbar_el1, m->cpu.trap_note[0] ? m->cpu.trap_note : "unknown (see ESR_EL1)");
            finish(m, A64M_FAULT); return m->state;
        }
        if (r == A64_RUN_HALTED) { finish(m, A64M_POWEROFF); return m->state; }
        if (r == A64_RUN_IDLE) {
            uint64_t t = m->cpu.idle_ticks;
            if (!realtime) {
                if (t) { a64_advance_time(&m->cpu, t); m->cpu.idle_ticks = 0; }
                else { m->state = A64M_IDLE; return m->state; }   /* nothing can ever wake it */
            } else {
                uint64_t us = t ? t * 1000000ull / A64_TIMER_HZ : 5000;
                if (us > 5000) us = 5000;
                if (us) { struct timespec ts = { 0, (long)(us * 1000) }; nanosleep(&ts, NULL); }
                if (t) { uint64_t adv = us * A64_TIMER_HZ / 1000000ull; if (!adv) adv = 1; a64_advance_time(&m->cpu, adv); }
                done += 1;      /* keep the loop responsive to stop requests */
            }
        }
    }
    return m->state;
}
