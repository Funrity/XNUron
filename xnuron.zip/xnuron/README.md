<p align="center"><img src="docs/xnuron.png" width="160" alt="XNUron"></p>

# XNUron (раньше — A64 Lab)

Собственный интерпретатор ARM64 (AArch64) на C + Android-оболочка. Экспериментальная платформа в сторону «iOS на Android».

**Честно: настоящую iOS это не загружает.** Подробно почему и что дальше — [docs/FEASIBILITY.md](docs/FEASIBILITY.md).

Что есть: EL0/EL1-эмуляция с исключениями/IRQ/таймером, виртуальная машина `a64virt` (RAM, UART, экран, касание),
собственное тестовое гостевое ядро, запуск самодостаточных Mach-O arm64 через эмуляцию BSD-сисколов, инспектор
Mach-O/IMG4/IPSW с объяснением, почему файл не запустится, Android-интерфейс (старт/стоп, экран, журнал, диагностика).

Тесты на ПК (нужны gcc, clang, ld.lld, llvm-objcopy, python3; java — по желанию):

    tests/run_all.sh

APK: открыть в Android Studio или GitHub → Actions → артефакт `xnuron-apk`
(в среде разработки APK не собирался — нет Android SDK/NDK).

Пересборка тестового гостя: `tools/build_guest.sh` (обновляет `guest_image.h`).


## IPSW boot attempt (0.2.2, experimental)

Source "Chosen file: IPSW - TRY to boot kernelcache". It really performs, in order: find the kernelcache in the ZIP (zip64, stored/deflate) ->
unwrap IM4P/IMG4 (DER) -> LZFSE (Apple's BSD reference decoder, `app/src/main/cpp/lzfse/`) or `complzss` decompression -> parse the arm64 Mach-O kernel ->
load its segments into a64virt RAM (physical = RAM base + 4 MiB + vm offset) -> optionally unwrap the DeviceTree -> build an XNU-style `boot_args`
(layout written from memory of XNU's public header: unverified) -> enter the kernel's LC_UNIXTHREAD entry at EL1, MMU off, x0 = boot_args.
Every step goes to the Boot log; the run ends with the real emulator fault (kernel virtual PC, instruction word, registers).

It stops *before* executing anything, and says so, when: the payload carries a KBAG (encrypted; no keys are held, derived or fetched), the kernel is 32-bit ARM,
the data is not an arm64 Mach-O, or no kernelcache is present. It never decrypts, patches, skips signature checks or reports a success it did not observe.
Expect modern kernels to fault within the first instructions (Apple system registers, PAC/SIMD, enabling the MMU). That is the intended, honest outcome of this feature.

Tests: `tests/run_all.sh` group 5b builds synthetic IPSWs (arm64 test kernel in IM4P+LZFSE, IM4P+complzss, plain, encrypted, 32-bit, garbage, no kernel) and checks the log and states.


## UI (0.3.0)

One screen in Material 3 style (dynamic colour on Android 12+, baseline palette otherwise; follows light/dark): a source card (file name, what Run will do),
"Choose file" and "Demos", one large Run/Stop button, and a Display / Log / Info switch. The run mode is chosen from the inspector result
(Mach-O -> user mode, IPSW -> boot attempt, unknown -> raw image, anything else is refused with the reason in Info). The display tab opens by itself when the guest starts drawing.

## Software MMU (0.3.6)
Stage-1 EL1&0 translation: 4K/16K/64K granules, TTBR0/TTBR1, TBI, block/page descriptors, access flag (HA optional), proper DFSC/FAR on aborts, translated instruction fetch, 256-entry TLB flushed on TTBR/TCR/SCTLR writes and TLBI. Permission bits (AP/XN/PXN/PAN, Apple APRR), ASIDs, stage 2 and 52-bit addresses are NOT modelled. Tested by `tests/asm/mmu.S` (guest builds its own page tables). UI: the Info tab and the built-in demo/test kernels are gone from the app (they remain only as host-side tests); tabs are Display / Kernel (what the guest writes) / Emulator (what the emulator says).

## SIMD / floating point (0.3.13)
`simd.inc` (included by `arm64.c`): V0-V31, all SIMD&FP loads/stores (incl. LD1-LD4/ST1-ST4, lane and replicate), scalar single/double FP (arithmetic, compare, convert, FMOV, FCSEL, FMADD family), and the common AdvSIMD groups (copy, modified immediate, three-same, two-register misc, across lanes, shift by immediate, permutes, EXT, TBL). Verified by a differential test (`tests/diff/simdprog.c`, clang at -O0..-O3 auto-vectorising to NEON vs a host build) and hand-checked asm (`tests/asm/simd_tests.S`). An instruction outside this subset stops the emulator with "unimplemented SIMD/FP instruction 0x........" instead of faulting the guest. Not modelled: half precision, FPCR modes, FPSR flags, FP traps, crypto/dot-product.

## 0.3.17 – device-tree fix-up
The 0.3.16 log showed the kernel walking the DeviceTree and stepping 2 GiB past a property (pointer 0xc0010078): in Apple's tree a
property length with bit 31 set marks a placeholder that iBoot resolves before booting, and the kernel's walker does not mask it.
The attempt now clears only that flag (bytes unchanged, nothing invented) and logs it as a MODELLED subset of iBoot's work.
Also logs the first guest reads of boot_args and the last 48 instructions before the first exception.

## 0.3.18 – diagnostics for the next stop
After the device-tree fix the first fault is `mrs x8,TPIDR_EL1; ldr x8,[x8,#0x468]` with TPIDR_EL1 = 0 (the kernel's per-thread pointer
has not been set yet). The log now also shows the frame-pointer call chain and any text the registers point to at the first exception,
and every guest write to TPIDR_EL1 (or that it was never written).

## 0.3.19 – boot CPU
0.3.18's log showed the kernel's own message: "unable to determine boot cpu!" (the kernel panicked correctly, then crashed because
TPIDR_EL1 was still 0 that early). iBoot normally marks the boot CPU's node under /cpus with state="running". The attempt now does the same
(first cpu node with a "state" property, same 8 bytes), logs all cpu nodes, and models MPIDR_EL1 = 0x80000000 | reg of that node. Modelled, labelled as such.

## 0.3.20 – LSE atomics
0.3.19 got past the boot-CPU check (TPIDR_EL1 set by the kernel itself). The next stop was an "undefined instruction" `b829011f`, which is
`ldadd w9, wzr, [x8]` (= STADD) from ARMv8.1 Large System Extensions. Implemented (single core: load-modify-store): LDADD/LDCLR/LDEOR/LDSET/
LDSMAX/LDSMIN/LDUMAX/LDUMIN (B/H/W/X, A/L variants), SWP, LDAPR, CAS, CASP, LDXP/STXP. ID_AA64ISAR0_EL1 now reports Atomic=2.
No memory-ordering effects are modelled (one core, sequential). Test: tests/asm/lse_tests.S.

## 0.3.21 – PAN
0.3.20's log: the kernel ran ~48k more instructions, then `d500419f` = `msr PAN, #1` (ARMv8.1 Privileged Access Never) was undefined.
PSTATE.PAN is now tracked (set/cleared by MSR, saved in SPSR bit 22, restored by ERET, set on exception entry when SCTLR_EL1.SPAN=0,
readable as the PAN register, advertised in ID_AA64MMFR1_EL1) but NOT enforced: the MMU has no AP/PXN permission checks (documented limitation).

## 0.3.22 – entropy placeholders
0.3.21's log is a genuine kernel panic: `EntropyData needed %lu bytes, but got %u.` (the kernel's trap `udf #0xdeff` follows the panic).
iBoot fills /chosen `random-seed` / `entropy-data` with random bytes; in the IPSW tree they are empty placeholders. The attempt now fills
each all-zero such property with bytes from the host's random source (/dev/urandom), lists all /chosen properties, and logs this as a MODELLED iBoot step.
Also: for registers at the first exception that point to kernel data, the log shows the first four 64-bit words (decodes panic() arguments).

## 0.3.23 – data-access history
0.3.22's log: the entropy panic is gone (the kernel got its random-seed) and the run continues ~80k instructions further. The new first
fault is a software page-table walk (`pmap`-style) in the kernel: it reads entry 7 of the root table that its own global points to, gets 0,
turns it into physical address 0 and dereferences phystokv(0). To see which table that global points to and what the kernel wrote there before,
the log now contains the last 40 data accesses (pc, read/write, size, virtual address, value) before the first exception.

## 0.3.24 – AT (address translation) instructions
0.3.23's access log showed the kernel's own root table (global at 0xfffffff0077ddee0 -> 0xfffffff0077a4000) holding entry 7 = 0x3: a valid table
descriptor whose address field is 0. Table addresses are normally produced by the kernel's virtual-to-physical routine, which on arm64 uses
`AT S1E1R` + `mrs PAR_EL1`. The emulator treated `SYS` (AT) as a no-op, so PAR_EL1 stayed 0 and the address came out as 0. AT S1E1R/W and
S1E0R/W now run the stage-1 walk and fill PAR_EL1 (PA, F/FST on faults; permissions not modelled). The panic report counts AT executions.
This is the most likely cause, not a proven one: the next log shows whether it was.

## 0.3.25 – diagnostic: store watch on the kernel global holding the DeviceTree base (0xfffffff0091baaa8)
The panic report lists the first 16 stores to it (value, pc) to find where 0x6ce50000 comes from.

## 0.3.26 – diagnostic: registers and code around the stores to the DeviceTree base global
0.3.25 showed two stores: 0x40010000 (pc 0x810e17c) and then a different, run-dependent value 0x58e50000/0x6ce50000 (pc 0x7ba3788). The report now includes registers and the preceding code for these stores.

## 0.3.27 – shorter panic report
0.3.26 log was cut. The report now prints store #2 (the run-dependent DT pointer) first and omits the boot_args access list.

## 0.3.28 – longer code window before the DT-pointer store #2

## 0.3.29 – deviceTreeP is a kernel virtual address (MODELLED)
0.3.28 trace: the kernel does DT_global = old_value + (new_region_va - old_region_va). With a physical deviceTreeP that gives garbage (0x64e50000). The DT now sits above the kernel data (phys top+1 MiB) and boot_args.deviceTreeP is its kernel virtual address (only for high-half kernels; the flat test kernel keeps the physical one).

## 0.3.30 – diagnostics after 0.3.29
0.3.29 log: deviceTreeP now virtual; the kernel remaps the region to a random VA (0xfffffff00e218000) but the data there reads as ASCII ("external...") instead of the DT header. The report now walks that VA and shows the DT physical words.

## 0.3.31 – DT placed 0x20000 above the physical address deviceTreeP names (MODELLED, from the 0.3.30 trace)
The kernel remapped the DT region at a random VA, but that VA translated to phys 0x433f8000 while the DT was at 0x433d8000 (intact). The kernel maps the region from topOfKernelData+0x20000 (code: add x12, top, #32, lsl #12), so the DT is now placed 0x20000 higher. This is an empirical shim, not a documented iBoot layout.

## 0.3.32 – DT at topOfKernelData+0x120000, deviceTreeP points exactly at it (MODELLED)
0.3.31 log showed the kernel no longer relocates the DT when it sits clear of its early page-table area (tables now built at 0x432d8000/0x432dc000), and then reads it through its own linear map at the virtual address deviceTreeP names. The 0.3.31 +0x20000 shim was wrong (the pointer pointed 0x20000 below the DT) and is removed; only the placement stays.
New stop: "No cpus found!" – the kernel found no DT at the old address (it read zeros).

## 0.3.33 – diagnostic only
0.3.32 log: DT early read OK (pointer -> DT), then the kernel slides the pointer by delta and maps the region so that the slid pointer lands 0x20000 above the DT (inside the DT, which is why it reads "external..." garbage). The panic report now dumps the mapping routine (0xfffffff007ba1a70, 0x140 bytes).

## 0.3.34 – diagnostic only: dump the whole routine around 0xfffffff007ba3380..0x7ba3640
0.3.33 showed the mapping routine (va, size, delta, flags). It is a per-32MiB L2/L3 mapper; the last call in the region loop has size 0 (x21=0). The caller loop builds the region list; its start is needed to see where the region bases and the 0x20000 come from.

## 0.3.35 – diagnostic: who writes the two kernel globals the region-slide uses
0.3.34 code: the kernel builds a region list; each region maps new_va -> physical start [page 0xfffffff0077de000 + 1496] while the DT pointer is slid by (new_va - [+1096]). The two bases differ by 0x20000 (0x432f8000 vs 0x432d8000). The report now lists the first stores to both globals.

## 0.3.36 – diagnostic: arguments of every call to the range-mapping routine (0xfffffff007ba1a70)
0.3.35: [+1096]=0xfffffff0092d8000 (virt of topOfKernelData) and [+1496]=0xfffffff0092bc000 (__LINKEDIT start) are written by the kernel itself (pc 0x7ba2eb0 / 0x7ba2b9c). The DT slide adds (new_va - 0x92d8000) while the region maps to top+0x20000: the 0x20000 is most likely the kernel own early page tables allocated at topOfKernelData. The report now lists the mapping calls (va, size, delta).

## 0.3.37 (diagnostic only)
The call trace of the region-mapping routine now records only calls with a non-zero delta (x2), up to 40, because the first 16 calls of 0.3.36 were all the kernel's own image at its old addresses (delta 0). This should list the relocated regions and which physical range backs the last one.

## 0.3.38 (fix of the DeviceTree layout, MODELLED)
The 0.3.37 trace of the kernel's own region list showed how it expects memory to be laid out: one region [end of kernel image, topOfKernelData) directly behind the image (the DT pointer is slid with that region's delta), then the memory above topOfKernelData + 0x20000 (its own first page tables). Before, the DT was placed above topOfKernelData, so the slid pointer was 0x20000 off. Now the DT sits right behind the image and topOfKernelData is the 16K-aligned end of the DT.
Also fixed: boot_args.memSize now counts from physBase (the kernel computes end = physBase + memSize; it was 0x10e4000 too large). Diagnostics: watch of kernel global +1064 instead of +1496.

## 0.3.39 (Apple S5L UART, MODELLED)
0.3.38 confirmed the DeviceTree layout fix: the kernel now slides the DT pointer correctly and runs ~60 million instructions. It then stops on a store to virtual 0xfffffff016000000, which the kernel itself maps to physical 0x235200000 (device memory): the console UART, for which no device existed (external abort).
- New: the UART node(s) under /arm-io are read from the DeviceTree (`ranges` of arm-io + `reg` of uart*), and an Apple S5L UART is modelled at the resulting physical address: UTRSTAT always reports "transmitter empty", nothing is received, other registers read back; bytes written to UTXH go to the Kernel tab. The DT facts (raw ranges, reg values, computed address) are logged.
- New diagnostic: the stop report says whether a physical address with no RAM and no device was accessed (first address, read/write).
- Tests: DT parsing of both `ranges` layouts, malformed trees, missing ranges; the UART model driven by real guest instructions.

## 0.3.40 (fix: arm-io `ranges` parsing)
The 0.3.39 log showed the real `ranges` of /arm-io is 48 bytes (two entries of u64 child, u64 parent, u64 size: 0 -> 0x200000000, size 0x100000000, ...), not 24, so no UART device was made and the kernel's console write (physical 0x235200000, uart0) still hit nothing. Parsing now accepts any number of entries (24-byte or 16-byte layout), picks the entry that contains each uart's `reg`, and logs every entry. Test added for the 48-byte shape.
The "unknown instruction" at 0x7a43b98 seen in 0.3.38/.39 is Apple's trap opcode (0xe7ffdeff) after a call to a panic routine: it is the kernel's panic path after the UART fault, not a separate emulator gap.

## 0.3.41 (EL1 physical timer registers; clearer stop message)
0.3.40 log: the UART works (three S5L UARTs from the DeviceTree) and the kernel went on to `msr CNTP_CTL_EL0` (S3_3_C14_C2_1), which was missing, so it trapped and the kernel's own panic path then spun. Added CNTP_CTL/CVAL/TVAL_EL0 (registers plus ISTATUS; the timer interrupt is NOT delivered - Apple routes it as FIQ, not modelled yet). The stop message no longer says "waiting for hardware" when the loop follows an exception, and prints the real number of guest output bytes (it used to say "none" unconditionally).

## 0.3.42 (diagnostics for the kernel's own panic)
With UART and CNTP registers in place the kernel now runs far enough to panic by itself and prints it on the Kernel tab: `panic(cpu 0 caller 0xfffffff007ab26ec): "Invalid waitq: 0xfffffff0091aef48"` (kernel data abort follow-ups, same text repeated). The waitq lives in kernel BSS; the question is why it was never initialised. This build only adds diagnostics: two code windows (the function that panicked and its caller), a data window around the waitq, and a record of which instructions store into the waitq and its 256-byte neighbourhood. The stop report also keeps the older diagnostics out of the way.

## 0.3.43 (diagnostics, second round on "Invalid waitq")
0.3.42 showed the waitq the kernel rejected (0xfffffff0091aef48) is all zeros and that nothing ever stored into it or the 256 bytes before it, i.e. it was never initialised (the panicking function tests a flag bit in its first word). The caller picks a "global waitq" by hashing an event (index = hash & (N-1), base + index * size). This build records the last 40 executions of that call (x0 = the waitq, plus the registers holding base, mask, index, stride) and dumps the caller's preamble, so it can be seen whether earlier calls used valid waitqs, and what N is. Panic-trap first exceptions no longer print the long "last accesses / instructions" lists (they were noise and made the log get cut).

## 0.4.0 — ребрендинг: XNUron
Технические идентификаторы тоже сменены: пакет и applicationId `com.xnuron.app` (старые `com.example.a64lab` больше нет), имена JNI, артефакт сборки `xnuron-apk`, архив `xnuron.zip`. Это новое приложение: старую версию придётся удалить, поверх она не встанет. Проект переехал в новый репозиторий. Содержимое 0.3.43 (диагностика «Invalid waitq») без изменений.

## 0.4.2

Новый значок и аватар проекта (красный фон, логотип с яблоком и орбитой). Адаптивный значок: логотип уменьшен и стоит в безопасной зоне, поэтому маска лаунчера (круг, «squircle») его не обрезает. Для Android 7 — обычные квадратные и круглые значки.

## 0.4.3

**Настройки.** Шестерёнка справа вверху открывает панель (Material 3, крупные скругления): тема «System / Light / Dark» и цвета «XNUron (red)» / «Dynamic». По умолчанию — фирменная красно-белая тема (в тёмной — тёмно-красная); «Dynamic» берёт цвета обоев (Material You, Android 12+; на старых версиях недоступно). Выбор запоминается; после смены экран пересоздаётся (идущий запуск при этом останавливается). Надпись «Experimental AArch64 emulator» убрана.

**Диагностика «Invalid waitq».** По логу 0.4.1: паника берёт глобальную очередь `0xfffffff0091aef48` из массива в BSS (нули, в ядре не записывалась), базу и размер массива читает из структуры на `0xfffffff008f95c00/08`. Теперь стоп-отчёт печатает эту структуру (окно данных 1), чтобы увидеть, запущена ли инициализация массива вообще. Исправления эмулятора тут пока нет: причина не подтверждена.

## 0.4.4

Из лога 0.4.3: структура глобальных очередей на `0xfffffff008f95c00` содержит базу массива `0xfffffff0091aef48` и размер 1, то есть массив зарегистрирован, но его единственный элемент (нули, ни одной записи) не инициализирован. Паника — первая же операция над ним. Теперь отчёт показывает (а) вызовы функции проверки очереди `0xfffffff007ab269c` (последние 40, с x0 = очередь), чтобы увидеть, работали ли до этого другие очереди, и (б) кто и когда пишет в базу/размер массива (`pc=значение`) либо они лежат в образе статически.

## 0.4.5

Из лога 0.4.4: массив глобальных очередей получает базу во время работы кода ядра (запись по `pc=0xfffffff007ba0378`, значение `0xfffffff0091aef48`), размер остаётся 1, а в сам элемент очереди ни одной записи нет; функция проверки очереди вызывается один раз за весь запуск — сразу с этим пустым элементом. Значит, инициализация, которая должна идти после выделения массива, не выполняется. Теперь отчёт показывает код вокруг этой записи и 400 инструкций, выполненных сразу после неё, чтобы увидеть, куда уходит управление.

## 0.4.6

Из лога 0.4.5: `0xfffffff007ba0378` — это цикл самого ядра, который применяет цепочки релокаций (chained fixups) к своим данным; он и записал в статическую структуру адрес массива очередей. То есть массив — статический, а вот инициализирующего кода (он должен выставить в элементе флаг «valid», бит 5) мы не видели. Теперь стоп-отчёт ищет в образе ядра все инструкции, которые обращаются к этой структуре и к самому массиву (ADRP + LDR/STR/ADD), и помечает каждую `+` (выполнялась) или `-` (ни разу не выполнялась). Так видно, дошёл ли запуск до инициализирующей функции. Для этого включена карта покрытия кода ядра (по биту на инструкцию, около 280 КБ).
