public class CopyParts {
  static final int COPY_PART = 19000;
  static int partStart(String s, int end) { int start = Math.max(0, end - COPY_PART); if (start > 0) { int nl = s.indexOf('\n', start); if (nl >= 0 && nl + 1 < end) start = nl + 1; } return start; }
  public static void main(String[] a) {
    for (int len : new int[]{1, 500, 18999, 19000, 19001, 45000, 100000}) {
      StringBuilder sb = new StringBuilder(); int n = 0; while (sb.length() < len) sb.append("line ").append(n++).append(" xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n"); sb.setLength(len);
      String all = sb.toString(); int total = 0, end = all.length(); while (end > 0) { end = partStart(all, end); total++; }
      StringBuilder re = new StringBuilder(); end = all.length(); int start = partStart(all, end); boolean ok = true;
      for (int p = 0; p < total; p++) { String c = all.substring(start, end); if (c.length() > COPY_PART || c.isEmpty()) ok = false; re.insert(0, c); end = start; start = partStart(all, end); }
      if (!(ok && re.toString().equals(all))) { System.out.println("FAIL len=" + len); System.exit(1); }
    }
    System.out.println("ok: copy parts (<=19000 chars, contiguous, end first)");
  }
}
