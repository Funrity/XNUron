#include "../app/src/main/cpp/attempt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int fails;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("  FAIL: "); printf(__VA_ARGS__); printf("\n"); } } while (0)
static FILE *fp;
static int rd(void *u, uint64_t off, void *b, size_t n) { (void)u; if (fseek(fp, (long)off, SEEK_SET)) return -1; return fread(b, 1, n, fp) == n ? 0 : -1; }
static char *logof(A64Machine *m) { size_t n = a64m_log_size(m); char *s = malloc(n + 1); n = a64m_log_read(m, 0, s, n); s[n] = 0; return s; }
static char *slurp(const char *p, size_t *n) { FILE *f = fopen(p, "rb"); if (!f) { *n = 0; return NULL; } fseek(f, 0, SEEK_END); *n = ftell(f); fseek(f, 0, SEEK_SET); char *b = malloc(*n); if (fread(b, 1, *n, f) != *n) *n = 0; fclose(f); return b; }

static void one(const char *dir, const char *name, const char *want_state, const char *must[], const char *mustnot[], bool dump) {
    char p[512]; snprintf(p, sizeof p, "%s/%s", dir, name); fp = fopen(p, "rb");
    if (!fp) { fails++; printf("  FAIL: cannot open %s\n", p); return; }
    fseek(fp, 0, SEEK_END); long sz = ftell(fp);
    A64Machine *m = a64_attempt_ipsw(rd, NULL, (uint64_t)sz);
    fclose(fp);
    if (!m) { fails++; printf("  FAIL: %s: NULL machine\n", name); return; }
    A64MState st = a64m_run(m, 60000000, false);
    char *log = logof(m);
    printf("-- %s: state=%d steps=%llu\n", name, st, (unsigned long long)a64m_cpu(m)->steps);
    CHECK(!strcmp(want_state, "fault") ? st == A64M_FAULT : st != A64M_FAULT, "%s: unexpected state %d", name, st);
    for (int i = 0; must && must[i]; i++) CHECK(strstr(log, must[i]), "%s: log lacks \"%s\"", name, must[i]);
    for (int i = 0; mustnot && mustnot[i]; i++) CHECK(!strstr(log, mustnot[i]), "%s: log must not contain \"%s\"", name, mustnot[i]);
    CHECK(!strstr(log, "booted") && !strstr(log, "Booted"), "%s: log claims a boot", name);
    if (dump) printf("%s\n", log);
    free(log); a64m_destroy(m);
}
static int ent_rng(void *b, size_t n) { memset(b, 0xA5, n); return 0; }
int main(int argc, char **argv) {
    const char *d = argv[1]; bool dump = argc > 2;
    const char *ok[] = { "step 1", "step 6: __TEXT", "step 7", "test-kernel: started at EL1", "FAKE-DEVICETREE-BLOB", "enabling MMU now", "Apple register S3_4_C15_C2_1 first write", "0x55", "Apple register S3_0_C15_C1_0 first read", "MMU is on: VBAR_EL1 address does not translate", "[panic] last executed pc=", "NOT iOS booting", NULL };
    const char *ok_not[] = { "ATTEMPT ENDED BEFORE", NULL };
    one(d, "ok_lzfse.zip", "fault", ok, ok_not, dump);
    one(d, "ok_lzss_stored.zip", "fault", ok, ok_not, dump);
    one(d, "ok_plain.zip", "fault", ok, ok_not, dump);
    const char *enc[] = { "encrypted (KBAG", "ATTEMPT ENDED BEFORE ANY GUEST INSTRUCTION RAN", NULL };
    const char *enc_not[] = { "step 6", "step 7", NULL };
    one(d, "encrypted.zip", "fault", enc, enc_not, dump);
    const char *a32[] = { "AArch32", "ATTEMPT ENDED BEFORE", NULL };
    one(d, "arm32.zip", "fault", a32, NULL, dump);
    const char *gb[] = { "ATTEMPT ENDED BEFORE", "not a 64-bit arm64 Mach-O", NULL };
    one(d, "garbage.zip", "fault", gb, NULL, dump);
    const char *sp[] = { "step 7", "[panic] loop window", "stuck in a tight loop", "code 0x", NULL };
    one(d, "spin.zip", "fault", sp, NULL, dump);
    const char *vs[] = { "the loop follows an exception", "unimplemented system register S3_5_C9_C9_5", "its own handler", NULL };
    one(d, "vecspin.zip", "fault", vs, NULL, dump);
    const char *nk[] = { "no matching member", NULL };
    one(d, "nokernel.zip", "fault", nk, NULL, dump);
    /* LZSS decoder against an independent (python) encoder, incl. back-references */
    size_t n1, n2; char *in = slurp("lzss_in.bin", &n1); char b[512]; snprintf(b, sizeof b, "%s/lzss_in.bin", d); free(in); in = slurp(b, &n1);
    snprintf(b, sizeof b, "%s/lzss.cmp", d); char *cmp = slurp(b, &n2);
    char err[200]; size_t olen = 0; uint8_t *o = a64_unpack_payload((uint8_t *)cmp, n2, &olen, err, sizeof err);
    CHECK(o && olen == n1 && !memcmp(o, in, n1), "LZSS round trip failed: %s", o ? "content differs" : err);
    printf("-- LZSS round trip: %zu -> %zu -> %zu bytes\n", n1, n2, olen); free(o);
    /* corrupt streams must be rejected, not crash */
    { /* device-tree fix-up: root with 2 props (one flagged placeholder) and one child */
        uint8_t dt[512]; memset(dt, 0, sizeof dt); size_t q = 0; uint32_t u;
        u = 2; memcpy(dt + q, &u, 4); u = 1; memcpy(dt + q + 4, &u, 4); q += 8;
        memcpy(dt + q, "name", 4); u = 5; memcpy(dt + q + 32, &u, 4); memcpy(dt + q + 36, "root", 5); q += 36 + 8;
        memcpy(dt + q, "serial-number", 13); u = 0x80000000u | 12; memcpy(dt + q + 32, &u, 4); q += 36 + 12;
        u = 1; memcpy(dt + q, &u, 4); u = 0; memcpy(dt + q + 4, &u, 4); q += 8;
        memcpy(dt + q, "x", 1); u = 0x80000000u | 4; memcpy(dt + q + 32, &u, 4); q += 36 + 4;
        char fnm[40]; int r = a64_dt_fixup(dt, q, fnm);
        CHECK(r == 2 && !strcmp(fnm, "serial-number"), "dt fixup counted %d first '%s'", r, fnm);
        uint32_t chk; memcpy(&chk, dt + 8 + 36 + 8 + 32, 4); CHECK(chk == 12, "placeholder flag not cleared (%08x)", chk);
        CHECK(a64_dt_fixup(dt, q, fnm) == 0, "second pass must find nothing");
        uint8_t bad[16] = {9, 9, 9, 9, 9, 9, 9, 9}; CHECK(a64_dt_fixup(bad, sizeof bad, fnm) == -1, "garbage tree accepted");
        CHECK(a64_dt_fixup(dt, 20, fnm) == -1, "truncated tree accepted");
    }
    { /* boot-cpu fix-up: root -> cpus -> cpu0 (reg 0x100, state "waiting") */
        uint8_t dt[1024]; memset(dt, 0, sizeof dt); size_t q = 0; uint32_t u;
        #define NODE(np_, nc_) do { u = np_; memcpy(dt + q, &u, 4); u = nc_; memcpy(dt + q + 4, &u, 4); q += 8; } while (0)
        #define PROP(nm_, len_, data_) do { memcpy(dt + q, nm_, strlen(nm_)); u = len_; memcpy(dt + q + 32, &u, 4); memcpy(dt + q + 36, data_, len_); q += 36 + (((len_) + 3) & ~3); } while (0)
        NODE(1, 1); PROP("name", 5, "root");
        NODE(1, 1); PROP("name", 5, "cpus");
        uint32_t reg = 0x100; NODE(3, 0); PROP("name", 5, "cpu0"); PROP("reg", 4, &reg); PROP("state", 8, "waiting");
        char lg[600]; uint32_t rr = 0; int r = a64_dt_boot_cpu(dt, q, &rr, lg, sizeof lg);
        CHECK(r == 1 && rr == 0x100, "boot cpu fix-up r=%d reg=0x%x", r, rr);
        CHECK(strstr(lg, "cpu0 reg=0x100 state=waiting"), "cpu list: %s", lg);
        CHECK(!memcmp(dt + q - 8, "running", 8), "state not rewritten to running");
        CHECK(a64_dt_boot_cpu((uint8_t[8]){9,9,9,9,9,9,9,9}, 8, &rr, lg, sizeof lg) == -1, "malformed tree accepted");
    }
    { /* entropy fix-up: root -> chosen with an all-zero random-seed placeholder (flagged length already cleared) */
        uint8_t dt[1024]; memset(dt, 0, sizeof dt); size_t q = 0; uint32_t u;
        NODE(1, 1); PROP("name", 5, "root");
        NODE(2, 0); PROP("name", 7, "chosen"); uint8_t zeros[16] = {0}; PROP("random-seed", 16, zeros);
        size_t seed_at = q - 16;
        char lg[400]; size_t nb = 0; int r = a64_dt_entropy(dt, q, ent_rng, &nb, lg, sizeof lg);
        CHECK(r == 1 && nb == 16, "entropy fill r=%d bytes=%zu", r, nb);
        CHECK(dt[seed_at] == 0xA5 && dt[seed_at + 15] == 0xA5, "seed bytes not filled");
        CHECK(strstr(lg, "random-seed(16)"), "chosen list: %s", lg);
        CHECK(a64_dt_entropy(dt, q, ent_rng, &nb, lg, sizeof lg) == 0, "non-empty seed must not be overwritten");
    }
    { /* MODELLED iBoot property insertion: /chosen gets a uint32, the sibling node behind it must survive */
        uint8_t dt[1024]; memset(dt, 0, sizeof dt); size_t q = 0; uint32_t u;
        NODE(1, 2); PROP("name", 5, "root");
        NODE(2, 0); PROP("name", 7, "chosen"); uint8_t seed[8] = {1,2,3,4,5,6,7,8}; PROP("random-seed", 8, seed);
        NODE(1, 0); PROP("name", 5, "cpus");
        size_t n0 = q, cap = sizeof dt;
        CHECK(a64_dt_chosen_add_u32(dt, &q, cap, "security-domain", 1) == 1 && q == n0 + 40, "chosen insert: added, grew by 40 (q=%zu n0=%zu)", q, n0);
        CHECK(a64_dt_chosen_add_u32(dt, &q, cap, "security-domain", 1) == 0 && q == n0 + 40, "chosen insert: second add finds it present");
        char lg[400]; size_t nb = 0; int r = a64_dt_entropy(dt, q, ent_rng, &nb, lg, sizeof lg);
        CHECK(r == 0 && strstr(lg, "random-seed(8)") && strstr(lg, "security-domain(4)"), "chosen insert: tree still well-formed, list: %s (r=%d)", lg, r);
        CHECK(!memcmp(dt + q - 8, "cpus", 5), "chosen insert: sibling node intact");
        CHECK(a64_dt_chosen_add_u32(dt, &q, q + 10, "x", 1) == -1, "chosen insert: no room is refused");
        uint8_t bad[16] = {9,9,9,9,9,9,9,9}; size_t bn = 8; CHECK(a64_dt_chosen_add_u32(bad, &bn, 16, "x", 1) == -1, "chosen insert: malformed tree refused");
    }
    { /* UART nodes: root -> arm-io (ranges) -> uart0 (compatible, reg); both layouts of "ranges" */
        for (int lay = 0; lay < 3; lay++) {
            uint8_t dt[1024]; memset(dt, 0, sizeof dt); size_t q = 0; uint32_t u;
            uint32_t r16[4] = { 0, 2, 0, 0x40000000u }; uint64_t r24[3] = { 0, 0x200000000ull, 0x40000000ull }; uint64_t r48[6] = { 0, 0x200000000ull, 0x100000000ull, 0x100000000ull, 0x800000000ull, 0x1000000ull };   /* shape seen in a real tree */
            uint32_t reg[2] = { 0x35200000u, 0x4000 };
            NODE(1, 1); PROP("name", 5, "root");
            NODE(2, 1); PROP("name", 7, "arm-io"); if (lay == 0) PROP("ranges", 16, r16); else if (lay == 1) PROP("ranges", 24, r24); else PROP("ranges", 48, r48);
            NODE(3, 0); PROP("name", 6, "uart0"); PROP("compatible", 15, "uart-1,samsung"); PROP("reg", 8, reg);
            uint64_t pa[3] = {0}, sz[3] = {0}; char lg[1000]; int n = a64_dt_uarts(dt, q, pa, sz, lg, sizeof lg);
            CHECK(n == 1 && pa[0] == 0x235200000ull && sz[0] == 0x4000, "uart layout %d: n=%d pa=0x%llx sz=0x%llx log=%s", lay, n, (unsigned long long)pa[0], (unsigned long long)sz[0], lg);
            CHECK(strstr(lg, "uart0"), "uart log: %s", lg);
            CHECK(a64_dt_uarts((uint8_t[8]){9,9,9,9,9,9,9,9}, 8, pa, sz, lg, sizeof lg) == -1, "malformed tree accepted");
        }
        { /* no ranges -> no device */
            uint8_t dt[1024]; memset(dt, 0, sizeof dt); size_t q = 0; uint32_t u; uint32_t reg[2] = { 0x35200000u, 0x4000 };
            NODE(1, 1); PROP("name", 5, "root"); NODE(1, 1); PROP("name", 7, "arm-io"); NODE(3, 0); PROP("name", 6, "uart0"); PROP("compatible", 15, "uart-1,samsung"); PROP("reg", 8, reg);
            uint64_t pa[3], sz[3]; char lg[1000]; CHECK(a64_dt_uarts(dt, q, pa, sz, lg, sizeof lg) == 0, "uart without ranges must not produce a device");
        }
    }
    { /* 0.4.53: which /arm-io node covers a physical address (reg u64 addr, u64 size; ranges u64 child/parent/size) */
        uint8_t dt[1024]; memset(dt, 0, sizeof dt); size_t q = 0; uint32_t u; uint64_t r24[3] = { 0, 0x200000000ull, 0x40000000ull };
        uint64_t reg1[2] = { 0x3b100000ull, 0x100000 }, reg2[2] = { 0x35200000ull, 0x4000 };
        NODE(1, 1); PROP("name", 5, "root"); NODE(2, 2); PROP("name", 7, "arm-io"); PROP("ranges", 24, r24);
        NODE(3, 0); PROP("name", 4, "aic"); PROP("compatible", 14, "aic,1\0aic,pub"); PROP("reg", 16, reg1);
        NODE(2, 0); PROP("name", 6, "uart0"); PROP("reg", 16, reg2);
        char nn[40], cc[100]; uint64_t b = 0, z = 0;
        CHECK(a64_dt_find_pa(dt, q, 0x23b100000ull, nn, sizeof nn, cc, sizeof cc, &b, &z) == 1 && !strcmp(nn, "aic") && b == 0x23b100000ull && z == 0x100000 && !strncmp(cc, "aic,1", 5), "find_pa: aic node: name=%s base=0x%llx", nn, (unsigned long long)b);
        CHECK(a64_dt_find_pa(dt, q, 0x23b1fffffull, nn, sizeof nn, cc, sizeof cc, &b, &z) == 1 && !strcmp(nn, "aic"), "find_pa: last byte of the range");
        CHECK(a64_dt_find_pa(dt, q, 0x23b200000ull, nn, sizeof nn, cc, sizeof cc, &b, &z) == 0, "find_pa: one past the range is not found");
        CHECK(a64_dt_find_pa((uint8_t[8]){9,9,9,9,9,9,9,9}, 8, 0x23b100000ull, nn, sizeof nn, cc, sizeof cc, &b, &z) == -1, "find_pa: malformed tree");
        A64Machine *m = a64m_create_system(1u << 20);   /* the named unknown block labels its log lines */
        CHECK(a64m_add_unknown_mmio_named(m, 0x23b100000ull, 0x100000, "aic") == 0, "add named block");
        uint32_t code[] = { 0xD2C00040, 0xF2A76200, 0xB9400001, 0x14000000 };   /* x0 = 0x23b100000; ldr w1,[x0]; b . */
        memcpy(a64m_ram_at(m, A64M_RAM_BASE, sizeof code), code, sizeof code);
        a64m_run(m, 40, false);
        char *lg = logof(m);
        CHECK(a64m_cpu(m)->x[0] == 0x23b100000ull && a64m_cpu(m)->xab_n == 0 && strstr(lg, "unknown SoC block 'aic': read  +0x0"), "named block: read of +0 works and is labelled (x0=0x%llx)", (unsigned long long)a64m_cpu(m)->x[0]);
        free(lg); a64m_destroy(m);
    }
    { /* 0.4.56: property length of a named node, and a MODELLED fixed read value of an unknown block */
        uint8_t dt[1024]; memset(dt, 0, sizeof dt); size_t q = 0; uint32_t u; uint8_t mask[64] = {0};
        NODE(1, 1); PROP("name", 5, "root"); NODE(2, 1); PROP("name", 7, "arm-io"); PROP("ranges", 24, ((uint64_t[3]){0, 0x200000000ull, 0x40000000ull}));
        NODE(3, 0); PROP("name", 4, "aic"); PROP("ipid-mask", 64, mask); PROP("reg", 16, ((uint64_t[2]){0x3b100000ull, 0x8000}));
        int64_t pl = 0; char lg[300];
        CHECK(a64_dt_node_info(dt, q, "aic", "ipid-mask", &pl, lg, sizeof lg) == 1 && pl == 64 && strstr(lg, "ipid-mask(64)") && strstr(lg, "reg(16)"), "node_info: ipid-mask length %lld, list: %s", (long long)pl, lg);
        CHECK(a64_dt_node_info(dt, q, "aic", "nonexistent", &pl, lg, sizeof lg) == 1 && pl == -1, "node_info: absent property gives -1");
        CHECK(a64_dt_node_info(dt, q, "nosuchnode", "x", &pl, lg, sizeof lg) == 0, "node_info: absent node gives 0");
        CHECK(a64_dt_node_info((uint8_t[8]){9,9,9,9,9,9,9,9}, 8, "aic", "x", &pl, lg, sizeof lg) == -1, "node_info: malformed tree");
        A64Machine *m = a64m_create_system(1u << 20);
        CHECK(a64m_add_unknown_mmio_named(m, 0x23b100000ull, 0x8000, "aic") == 0 && a64m_unknown_set_read(m, 0x23b100000ull, 0x4, 512) == 0, "set_read on the block");
        CHECK(a64m_unknown_set_read(m, 0x300000000ull, 0x4, 1) == -1, "set_read on an unknown address is refused");
        uint32_t code[] = { 0xD2C00040, 0xF2A76200, 0xB9400402, 0xB9400003, 0x14000000 };   /* x0 = 0x23b100000 (the 0x3b10 imm is the same as in the other test); ldr w2,[x0,#4]; ldr w3,[x0]; b . */
        memcpy(a64m_ram_at(m, A64M_RAM_BASE, sizeof code), code, sizeof code);
        a64m_run(m, 40, false);
        CHECK(a64m_cpu(m)->x[2] == 512 && a64m_cpu(m)->x[3] == 0, "fixed read: +0x4 gave %llu (want 512), +0 gave %llu (want 0)", (unsigned long long)a64m_cpu(m)->x[2], (unsigned long long)a64m_cpu(m)->x[3]);
        char *l2 = logof(m); CHECK(strstr(l2, "read  +0x4 size 4 -> 0x200 (MODELLED value"), "fixed read is logged as MODELLED"); free(l2);
        a64m_destroy(m);
    }
    { /* 0.4.55: the system machine can hold more than 8 devices (it ran out at the 9th: 4 board devices + 3 UARTs + aic left no room for the memory-controller block) */
        A64Machine *m = a64m_create_system(1u << 20); int okn = 0;
        okn += a64m_add_s5l_uart(m, 0x235200000ull, 0x4000) == 0; okn += a64m_add_s5l_uart(m, 0x235204000ull, 0x4000) == 0; okn += a64m_add_s5l_uart(m, 0x23520c000ull, 0x4000) == 0;
        okn += a64m_add_unknown_mmio_named(m, 0x23b100000ull, 0x8000, "aic") == 0; okn += a64m_add_unknown_mmio(m, 0x200000000ull, 0x100000) == 0;
        CHECK(okn == 5, "all five SoC devices fit next to the board devices (%d of 5)", okn);
        a64m_destroy(m);
    }
    { /* the S5L UART model: a guest stores 'H' to UTXH and reads UTRSTAT (tx empty = 0x6) at the address given */
        A64Machine *m = a64m_create_system(1u << 20);
        CHECK(a64m_add_s5l_uart(m, 0x235200000ull, 0x4000) == 0, "add uart");
        uint32_t code[] = { 0xD2C00040, 0xF2A6A400, 0x52800901, 0xB9002001, 0xB9401002, 0x14000000 };
        memcpy(a64m_ram_at(m, A64M_RAM_BASE, sizeof code), code, sizeof code);
        a64m_run(m, 40, false);
        char b[64]; size_t k = a64m_log_read_kind(m, 1, 0, b, sizeof b - 1); b[k] = 0;
        CHECK(!strcmp(b, "H"), "UART output was '%s'", b);
        CHECK(a64m_cpu(m)->x[2] == 6, "UTRSTAT read gave 0x%llx", (unsigned long long)a64m_cpu(m)->x[2]);
        a64m_destroy(m);
    }
    { /* MODELLED unknown SoC block: reads 0, writes ignored, accesses logged (no external abort) */
        A64Machine *m = a64m_create_system(1u << 20);
        CHECK(a64m_add_unknown_mmio(m, 0x200000000ull, 0x4000) == 0, "add unknown block");
        uint32_t code[] = { 0xD2800040, 0xD3607C00, 0xD2801FE1, 0xB9468001, 0x52800AA2, 0xB9068402, 0x14000000 };   /* x0=0x200000000; x1=0xff; ldr w1,[x0,#0x680]; mov w2,#0x55; str w2,[x0,#0x684]; b . */
        memcpy(a64m_ram_at(m, A64M_RAM_BASE, sizeof code), code, sizeof code);
        a64m_run(m, 60, false);
        CHECK(a64m_cpu(m)->x[0] == 0x200000000ull, "x0 = 0x%llx", (unsigned long long)a64m_cpu(m)->x[0]);
        CHECK(a64m_cpu(m)->x[1] == 0, "unknown block read gave 0x%llx, want 0", (unsigned long long)a64m_cpu(m)->x[1]);
        CHECK(a64m_cpu(m)->xab_n == 0, "unknown block caused an external abort");
        char b[600]; size_t k = a64m_log_read(m, 0, b, sizeof b - 1); b[k] = 0;
        CHECK(strstr(b, "read  +0x680") && strstr(b, "write +0x684 size 4 value 0x55"), "access log missing: %s", b);
        a64m_destroy(m);
    }
    { /* EL1 physical timer registers (the kernel writes CNTP_CTL_EL0 right after the UART is up) */
        A64Machine *m = a64m_create_system(1u << 20);
        uint32_t code[] = { 0xD2800020, 0xD51BE220, 0xD53BE221, 0xD2800F02, 0xD51BE242, 0xD53BE243, 0x14000000 };   /* mov x0,#1; msr cntp_ctl,x0; mrs x1,cntp_ctl; mov x2,#0x78; msr cntp_cval,x2; mrs x3,cntp_cval; b . */
        memcpy(a64m_ram_at(m, A64M_RAM_BASE, sizeof code), code, sizeof code);
        a64m_run(m, 40, false);
        CHECK(a64m_cpu(m)->x[1] == 5, "CNTP_CTL read 0x%llx (want enable|istatus)", (unsigned long long)a64m_cpu(m)->x[1]);
        CHECK(a64m_cpu(m)->x[3] == 0x78, "CNTP_CVAL read 0x%llx", (unsigned long long)a64m_cpu(m)->x[3]);
        a64m_destroy(m);
    }
    uint8_t junk[64] = "bvx2\xff\xff\xff\xff"; o = a64_unpack_payload(junk, sizeof junk, &olen, err, sizeof err); CHECK(!o, "corrupt LZFSE accepted"); free(o);
    memcpy(junk, "complzss", 8); o = a64_unpack_payload(junk, sizeof junk, &olen, err, sizeof err); CHECK(!o, "short complzss accepted"); free(o);
    printf(fails ? "ATTEMPT TESTS FAILED (%d)\n" : "attempt tests ok\n", fails);
    return fails != 0;
}
